 .setcpu "65816"
.segment "CODE"
sei
sec
xce
cld
lda #0
pha
plb
.export EMULATION_ENTRY
EMULATION_ENTRY:

lda #$cc
sta $7fec
ldx #0
ldy #32
copy:
read: lda $8000,x
write: sta $3000,x
inx
bne copy
inc read+2
inc write+2
dey
bne copy
lda #0
sta $7fec
brk
.byte 0
