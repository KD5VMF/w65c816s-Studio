#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
CA65=${CA65:-/home/sysop/w65c816-basic/tools/bin/ca65}
LD65=${LD65:-/home/sysop/w65c816-basic/tools/bin/ld65}
export CA65_INC="$PWD/tools/asminc"
python3 tools/prepare_source.py
cd builds/generated
"$CA65" -D w65c816sxb -l ../basic-ram.lst msbasic.s -o ../basic-ram.o
"$LD65" -C ../../source/ram.cfg ../basic-ram.o -o ../basic-ram.bin -m ../basic-ram.map -Ln ../basic-ram.lbl
# ROM has a RAM return target for interrupts; hardware RESET restores bank 3.
printf '\n.segment "HWVECTORS"\n.repeat 16\n.word $0600\n.endrepeat\n' >> msbasic.s
"$CA65" -D w65c816sxb -D ROM_BUILD -l ../basic-rom.lst msbasic.s -o ../basic-rom.o
"$LD65" -C ../../source/rom.cfg ../basic-rom.o -o ../../rom-images/basic-bank0-CANDIDATE.bin -m ../basic-rom.map -Ln ../basic-rom.lbl
cd ../..
sha256sum builds/basic-ram.bin rom-images/basic-bank0-CANDIDATE.bin > builds/SHA256SUMS
cat builds/SHA256SUMS
"$CA65" launcher/launcher.s -o builds/launcher.o -l builds/launcher.lst
"$LD65" -C launcher/launcher.cfg builds/launcher.o -o launcher/launcher-CANDIDATE.bin
sha256sum launcher/launcher-CANDIDATE.bin >> builds/SHA256SUMS

python3 tools/build_flash_tools.py
