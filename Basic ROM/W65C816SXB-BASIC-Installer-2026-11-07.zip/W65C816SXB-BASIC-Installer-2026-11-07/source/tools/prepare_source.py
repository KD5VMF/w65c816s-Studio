#!/usr/bin/env python3
"""Generate build tree from pinned, unmodified upstream plus local platform files."""
from pathlib import Path
import shutil
R=Path(__file__).resolve().parents[1];d=R/'builds/generated'
if d.exists():shutil.rmtree(d)
shutil.copytree(R/'source/msbasic',d,ignore=shutil.ignore_patterns('.git'))
for p in (R/'source/platform').glob('*.s'):shutil.copy2(p,d/p.name)
p=d/'init.s';s=p.read_text()
# Fixed RAM ceiling: never probe monitor workspace or I/O to discover RAM size.
a=s.index('        lda     #<QT_MEMORY_SIZE');b=s.index('L40FA:')
s=s[:a]+'''        lda #<RAMSTART2
        sta TXTTAB
        lda #>RAMSTART2
        sta TXTTAB+1
.endif
        lda #<$7d00
        sta LINNUM
        lda #>$7d00
        sta LINNUM+1
'''+s[b:]
a=s.index('L4106:');b=s.index('L4136:')
s=s[:a]+'L4106:\n'+s[b:]
s=s.replace('.ifdef MICROTAN\n        .byte   "MICROTAN BASIC"','.ifdef MICROTAN\n        .byte   "MICROTAN BASIC"')
s=s.replace('QT_BASIC:\n','QT_BASIC:\n  .ifdef W65C816SXB\n        .byte "W65C816 BASIC"\n  .endif\n')
p.write_text(s)
p=d/'inline.s';s=p.read_text().replace('INLIN:\n','INLIN:\n.ifdef W65C816SXB\n        jmp UART_LINE\n.endif\n');p.write_text(s)
p=d/'message.s';s=p.read_text().replace('.byte   CR,LF,"OK",CR,LF','.byte   CR,LF,"READY",CR,LF');p.write_text(s)
p=d/'poke.s';s=p.read_text().replace('POKE:\n        jsr     GTNUM\n','''POKE:
        jsr     GTNUM
        lda LINNUM+1
        cmp #$04
        bne @denied
        ; POKE confined to dedicated scratch page $0400-$04FF.
        ; Prevent writes to monitor, flash controls, BASIC code and workspaces.
        bra @allowed
@denied: jmp IQERR
@allowed:
''');p.write_text(s)

p=d/'msbasic.s';p.write_text(p.read_text()+"\n.assert Z14 < TEMPPT, error, \"zero-page control overlaps string temporaries\"\n.assert CHRGET + (GENERIC_CHRGET_END-GENERIC_CHRGET) <= $100, error, \"CHRGET exceeds zero page\"\n")

p=d/'msbasic.s';p.write_text(p.read_text()+'\n.include "edu.s"\n')
p=d/'init.s';s=p.read_text();s=s.replace('lda     #<IQERR\n          ldy     #>IQERR','lda     #<EDU_USR\n          ldy     #>EDU_USR');p.write_text(s)
p=d/'poke.s';s=p.read_text();s=s.replace('cmp #$04\n        bne @denied','cmp #$04\n        beq @allowed\n        cmp #$7f\n        bne @denied\n        lda LINNUM\n        cmp #$a0\n        bcc @denied\n        cmp #$e0\n        bcs @denied');p.write_text(s)
p=d/'poke.s';s=p.read_text();a=s.index('WAIT:\n');b=s.index('RTS3:\n',a)
s=s[:a]+'''WAIT:
        jsr FRMNUM
        jsr GETADR
        lda LINNUM
        sta WAIT_LO
        lda LINNUM+1
        sta WAIT_HI
        jmp EDU_WAIT
'''+s[b:];p.write_text(s)
