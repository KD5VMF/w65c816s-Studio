; RAM-only SST39SF010A sector erase for the reviewed EDU/WAIT upgrade.
; ONLY bank0 sectors0..2; monitor and vector sector are outside allowed range.
.setcpu "65816"
.assert SECTOR >= 0 .and SECTOR < 3, error, "Only reviewed bank0 code sectors 0..2"
TARGET = $8000 + SECTOR * $1000
.segment "CODE"
sei
sec
xce
cld
lda #0
pha
plb
.export EMULATION_ENTRY, BUSY_HALT
EMULATION_ENTRY:
.setcpu "65C02"
lda #1
sta $2800
stz $2801
stz $2802
lda #$ff
sta $2803
stz $2804
stz $2805
stz $2806
lda #$53
sta $2807
lda #$cc
sta $7fec
lda #$aa
sta $d555
lda #$55
sta $aaaa
lda #$80
sta $d555
lda #$aa
sta $d555
lda #$55
sta $aaaa
lda #$30
sta TARGET
ldx #0
ldy #0
poll:
lda TARGET
cmp #$ff
beq check_blank
dey
bne poll
dex
bne poll
sta $2804
lda TARGET
eor TARGET
and #$40
beq failed
lda #4
sta $2800
BUSY_HALT:
.byte $db
bra BUSY_HALT
failed:
lda #3
sta $2800
bra leave
check_blank:
ldx #0
check:
read: lda TARGET,x
cmp #$ff
beq next
sta $2804
stx $2801
lda read+2
sta $2802
lda #2
sta $2800
bra leave
next:
inx
bne check
inc read+2
dec pages
bne check
stz $2800
leave:
lda #0
sta $7fec
brk
.byte 0
pages: .byte 16
