# Flash utilities

The user explicitly approved programming with "WORKS. FLASH IT" after physical RAM tests. Original backup was refreshed twice before the first command write. Software ID BF/B5 confirmed SST39SF010A; earlier 29/39 transcription ambiguity is resolved.

`identify-39.s` performs AA/55/90 ID entry, reads identifiers, writes F0 to exit, restores bank3/PCR00 and BRKs. `identify-29.s` was modeled for research, not used on hardware. Neither programs array bytes.

`program-chunk.s` is the actual bank0-only RAM byte programmer, built four times with CHUNK=0..3. Source data: $3000-$4FFF. CPU entry: $2000. Result: $2800 status (0 success,1 active,2 nonblank,3 stable verify failure,4 busy timeout), $2801/2 failure address, $2803 expected, $2804 actual, $2805/6 count, $2807 signature53. It blank-checks all 8192 target bytes before any programming, skips FF, sends only AA/55/A0/data, polls full-byte readback, and restores PCR00 before BRK. A still-busy timeout executes STP in RAM, requiring hardware reset rather than jumping into busy flash. No erase operation is present. Keep RESET/NMI inactive while programming because vector fetches also use the flash array.

25 modeled checks exercised the actual assembled binaries, including protected-bank sentinels, last-byte nonblank rejection, stable failure, stuck-busy timeout and the last address FFFF. Four physical all-FF dry runs returned success/count0 before the actual program operation.

The host programmer verifies pinned image approval, validated binary hashes, original/fresh backups, all current banks, live chip ID, RAM transfers, each chunk's whole-bank readback and final protected banks. It does not retry or erase. It will refuse a second install because bank0 now differs from the blank original.

Successful session and every readback are in builds/flash-write-20261107T154952Z/. Original firmware remains in flash-backups/.
