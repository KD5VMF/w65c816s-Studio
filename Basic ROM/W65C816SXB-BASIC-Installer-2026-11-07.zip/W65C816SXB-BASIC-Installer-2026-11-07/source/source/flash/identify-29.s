 .setcpu "65816"
.segment "CODE"
sei
sec
xce
cld
lda #0
pha
plb
.export EMULATION_ENTRY
EMULATION_ENTRY:

lda #$cc
sta $7fec
lda #$aa
sta $8555
lda #$55
sta $82aa
lda #$90
sta $8555
ldx #0
wait1: dex
bne wait1
ldx #7
copyid: lda $8000,x
sta $2800,x
dex
bpl copyid
lda #$f0
sta $8000
ldx #0
wait2: dex
bne wait2
lda #0
sta $7fec
brk
.byte 0
