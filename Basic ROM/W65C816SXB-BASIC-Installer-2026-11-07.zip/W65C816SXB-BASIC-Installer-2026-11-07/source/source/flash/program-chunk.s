; RAM-only 8 KiB programmer for verified SST39SF010A.
; Build with CHUNK=0..3. No erase opcode or arbitrary bank/target parameter.
; Source $3000-$4FFF; result $2800-$2807; executes at $2000.
.setcpu "65816"
.ifndef CHUNK
.error "CHUNK required"
.endif
.assert CHUNK >= 0 .and CHUNK < 4, error, "Only flash bank0 chunks 0..3"
TARGET = $8000 + CHUNK * $2000
.segment "CODE"
sei
sec
xce
cld
lda #0
pha
plb
.export EMULATION_ENTRY
EMULATION_ENTRY:
.setcpu "65C02"
lda #1
sta $2800
stz $2801
stz $2802
stz $2803
stz $2804
stz $2805
stz $2806
lda #$53
sta $2807
lda #$cc
sta $7fec
; Require the WHOLE chunk blank before issuing its first program sequence.
ldx #0
blank:
blank_read: lda TARGET,x
cmp #$ff
beq blank_next
sta $2804
stx $2801
lda blank_read+2
sta $2802
lda #2
sta $2800
jmp leave
blank_next:
inx
bne blank
inc blank_read+2
dec blank_pages
bne blank
ldx #0
next:
source: lda $3000,x
sta $2803
cmp #$ff
beq advance
lda #$aa
sta $d555
lda #$55
sta $aaaa
lda #$a0
sta $d555
lda $2803
program_target: sta TARGET,x
ldy #0
poll:
poll_target: lda TARGET,x
cmp $2803
beq programmed
dey
bne poll
; Determine whether a failed program has finished or is still busy.
sta $2804
stx $2801
lda poll_target+2
sta $2802
stable1: lda TARGET,x
stable2: eor TARGET,x
and #$40
beq failed_stable
lda #4
sta $2800
; Busy beyond timeout: stay in RAM. Never branch into busy flash.
.export BUSY_HALT
BUSY_HALT:
.byte $db ; W65C816 STP, released only by hardware reset
bra BUSY_HALT
failed_stable:
lda #3
sta $2800
jmp leave
programmed:
inc $2805
bne advance
inc $2806
advance:
inx
bne next
inc source+2
inc program_target+2
inc poll_target+2
inc stable1+2
inc stable2+2
dec pages
bne next
stz $2800
leave:
lda #0
sta $7fec
brk
.byte 0
blank_pages: .byte 32
pages: .byte 32
