CONFIG_2C := 1
CONFIG_NO_CR := 1
CONFIG_SCRTCH_ORDER := 2
CONFIG_SAFE_NAMENOTFOUND := 1
CONFIG_PEEK_SAVE_LINNUM := 1
ZP_START1 := $00
ZP_START2 := $0D
ZP_START3 := $5B
ZP_START4 := $66 ; full precision VALTYP uses two bytes; $65 overlaps Z14
USR := $000A
STACK_TOP := $FC
SPACE_FOR_GOSUB := $33
WIDTH := 72
WIDTH2 := 56
.ifdef ROM_BUILD
RAMSTART2 := $0800
.else
RAMSTART2 := $5000
.endif
SAVE:
LOAD:
        jmp IQERR ; unavailable; explicit error rather than pretending success
