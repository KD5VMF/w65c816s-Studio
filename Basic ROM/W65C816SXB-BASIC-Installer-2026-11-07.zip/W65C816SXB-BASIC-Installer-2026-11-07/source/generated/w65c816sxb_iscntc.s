.segment "CODE"
ISCNTC:
        jsr RX_POLL
        lda BREAK_PENDING
        bne @stop
        rts
@stop:  stz BREAK_PENDING
        lda #0
        sec
; falls into upstream STOP
