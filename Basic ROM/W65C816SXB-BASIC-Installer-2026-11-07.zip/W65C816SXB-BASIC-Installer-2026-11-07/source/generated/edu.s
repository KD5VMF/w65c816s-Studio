; EDU access ABI v1. Mailbox $0400 command, $0401-$0404 args,
; $0410 byte result, $0411 status (0=OK,1=NACK,2=bad command/address,3=timeout).
; No BASIC zero-page scratch is used. All hardware state is in private $0220+.
.segment "EXTRA"
.export EDU_USR, EDU_DISPATCH, EDU_INIT
ED_CMD=$0400
ED_ARG=$0401
ED_RET=$0410
ED_STATUS=$0411
ED_BYTE=$0220
ED_IN=$0221
ED_BUSY=$0222
ED_COUNT=$0223
PIA_PA=$7fa0
PIA_CRA=$7fa1
VIA_PA=$7fcf
VIA_DDRA=$7fc3
VIA_PB=$7fc0
VIA_DDRB=$7fc2
EDU_INIT:
        stz ED_CMD
        stz ED_ARG
        stz ED_RET
        stz ED_STATUS
        rts
EDU_USR:
        jsr EDU_DISPATCH
        ldy ED_RET
        jmp SNGFLT
EDU_DISPATCH:
        stz ED_STATUS
        stz ED_RET
        lda ED_CMD
        beq edu_info
        cmp #1
        beq edu_led
        cmp #2
        beq edu_buzzer
        cmp #3
        beq edu_start_jump
        cmp #4
        beq edu_stop_jump
        cmp #5
        beq edu_write_jump
        cmp #6
        beq edu_read_ack_jump
        cmp #7
        beq edu_read_nack_jump
        cmp #8
        beq edu_spi_init_jump
        cmp #9
        beq edu_spi_select_jump
        cmp #10
        beq edu_spi_byte_jump
        cmp #11
        beq edu_ram_read_jump
        cmp #12
        beq edu_ram_write_jump
        lda #2
        sta ED_STATUS
        rts
edu_info:
        lda #1 ; ABI version
        sta ED_RET
        rts
edu_led:
        ; PIA CRA 30 selects DDRA and holds CA2/buzzer low.
        lda #$30
        sta PIA_CRA
        lda #$ff
        sta PIA_PA
        lda #$34
        sta PIA_CRA
        lda ED_ARG
        sta PIA_PA
        sta ED_RET
        rts
edu_buzzer:
        lda #$34
        ldx ED_ARG
        beq @off
        lda #$3c
@off:   sta PIA_CRA
        rts
edu_start_jump: jmp edu_i2c_start
edu_stop_jump: jmp edu_i2c_stop
edu_write_jump: jmp edu_i2c_write
edu_read_ack_jump: lda #0
        jmp edu_i2c_read
edu_read_nack_jump: lda #1
        jmp edu_i2c_read
edu_spi_init_jump: jmp edu_spi_init
edu_spi_select_jump: jmp edu_spi_select
edu_spi_byte_jump: jmp edu_spi_byte
edu_ram_read_jump: lda #$af
        bra edu_ram
edu_ram_write_jump: lda #$8f
edu_ram:
        sta $0500
        lda ED_ARG+2 ; 65816 bank, only EDU's documented $08-$0F.
        cmp #8
        bcc @invalid
        cmp #16
        bcs @invalid
        sta $0503
        lda ED_ARG
        sta $0501
        lda ED_ARG+1
        sta $0502
        lda #$60
        sta $0504
        lda ED_ARG+3
        jsr $0500 ; LDA/STA long, RTS; valid in 65816 emulation mode.
        sta ED_RET
        rts
@invalid:
        lda #2
        sta ED_STATUS
        rts
; Delay keeps bus below 100 kHz even at SXB 8 MHz; preserves A/X/Y.
edu_delay:
        phx
        ldx #20
@wait:  dex
        bne @wait
        plx
        rts
; Release SCL and wait for physical high. Bounded clock stretching.
edu_clock_high:
        lda VIA_DDRA
        and #$fe
        sta VIA_DDRA
        phx
        ldx #0
@wait:  lda VIA_PA
        and #1
        bne @high
        dex
        bne @wait
        lda #3
        sta ED_STATUS
@high:  plx
        jmp edu_delay
edu_clock_low:
        lda VIA_DDRA
        ora #1
        sta VIA_DDRA
        jmp edu_delay
edu_data_high:
        lda VIA_DDRA
        and #$7f
        sta VIA_DDRA
        jmp edu_delay
edu_data_low:
        lda VIA_DDRA
        ora #$80
        sta VIA_DDRA
        jmp edu_delay
edu_i2c_start:
        ; Keep open-drain output latches low; DDR selects low/released.
        lda VIA_PA
        and #$7e
        sta VIA_PA
        jsr edu_data_high
        jsr edu_clock_high
        lda ED_STATUS
        bne @done
        jsr edu_data_low
        jsr edu_clock_low
@done:  rts
edu_i2c_stop:
        jsr edu_data_low
        jsr edu_clock_high
        jmp edu_data_high
edu_i2c_write:
        lda ED_ARG
        sta ED_BYTE
        ldy #8
@bit:   asl ED_BYTE
        bcs @one
        jsr edu_data_low
        bra @clock
@one:   jsr edu_data_high
@clock: jsr edu_clock_high
        jsr edu_clock_low
        dey
        bne @bit
        jsr edu_data_high
        jsr edu_clock_high
        lda VIA_PA
        and #$80
        beq @ack
        lda #1
        sta ED_STATUS
@ack:   jmp edu_clock_low
edu_i2c_read:
        sta ED_BUSY ; 0=ACK,1=NACK for last byte.
        stz ED_IN
        jsr edu_data_high
        ldy #8
@bit:   jsr edu_clock_high
        lda VIA_PA
        asl a ; SDA bit 7 into carry
        rol ED_IN
        jsr edu_clock_low
        dey
        bne @bit
        lda ED_BUSY
        bne @nack
        jsr edu_data_low
@nack:  jsr edu_clock_high
        jsr edu_clock_low
        jsr edu_data_high
        lda ED_IN
        sta ED_RET
        rts
edu_spi_init:
        lda VIA_PB
        and #$fc
        ora #$0c
        sta VIA_PB
        lda VIA_DDRB
        and #$df
        ora #$0f
        sta VIA_DDRB
        rts
edu_spi_select:
        ; arg 0=none,1=SRAM,2=Click. Never assert both.
        lda ED_ARG
        cmp #3
        bcs @bad
        tax
        lda VIA_PB
        ora #$0c
        cpx #1
        bne @click
        and #$fb
@click: cpx #2
        bne @set
        and #$f7
@set:   sta VIA_PB
        rts
@bad:   lda #2
        sta ED_STATUS
        rts
edu_spi_byte:
        lda ED_ARG
        sta ED_BYTE
        stz ED_IN
        ldy #8
@bit:   asl ED_BYTE
        lda VIA_PB
        and #$fc
        bcc @zero
        ora #2
@zero:  sta VIA_PB
        jsr edu_delay
        ora #1
        sta VIA_PB
        jsr edu_delay
        lda VIA_PB
        and #$20
        cmp #$20
        rol ED_IN
        lda VIA_PB
        and #$fe
        sta VIA_PB
        jsr edu_delay
        dey
        bne @bit
        lda ED_IN
        sta ED_RET
        rts

; Millisecond WAIT for the SXB's documented 8 MHz clock. UART remains polled.
.export EDU_WAIT, EDU_WAIT_DONE, WAIT_LO, WAIT_HI
WAIT_LO=$0240
WAIT_HI=$0241
WAIT_HALF=$0242
EDU_WAIT:
        lda WAIT_LO
        ora WAIT_HI
        beq @done
@next:  jsr edu_wait_tick
        jsr ISCNTC
        lda WAIT_LO
        bne @decrement
        dec WAIT_HI
@decrement:
        dec WAIT_LO
        lda WAIT_LO
        ora WAIT_HI
        bne @next
@done:
EDU_WAIT_DONE:
        rts
edu_wait_tick:
        nop
        nop
        nop
        nop
        nop
        bit WAIT_LO
        nop
        phx
        phy
        lda #2
        sta WAIT_HALF
@half:  jsr RX_POLL
        ldx #3
@outer: ldy #0
@inner: dey
        bne @inner
        dex
        bne @outer
        ldx #2
@trim:  dex
        bne @trim
        dec WAIT_HALF
        bne @half
        ply
        plx
        rts
