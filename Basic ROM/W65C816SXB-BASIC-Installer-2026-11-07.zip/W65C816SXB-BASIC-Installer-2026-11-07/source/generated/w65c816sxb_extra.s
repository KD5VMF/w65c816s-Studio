.segment "EXTRA"
.export MONRDKEY_NB, MONRDKEY, MONCOUT, INITUSBSERIAL
.export UART_LINE, RX_POLL, BREAK_PENDING
RX_HEAD = $0200
RX_TAIL = $0201
BREAK_PENDING = $0202
LAST_CR = $0203
RX_OVERFLOW = $0204
RX_ERRORS = $0205
RX_RING = $0300
INITUSBSERIAL:
        stz RX_HEAD
        stz RX_TAIL
        stz BREAK_PENDING
        stz LAST_CR
        stz RX_OVERFLOW
        stz RX_ERRORS
        lda #0
        sta $7f81
        lda #$1f ; internal 1.8432 MHz reference, 19200 baud, 8N1
        sta $7f83
        lda #$0b ; DTR/RTS asserted, RX/TX interrupt disabled, no parity/echo
        sta $7f82
        rts
; Polling RX runs while waiting for input, during TX delay, and at BASIC break checks.
; Ring holds up to 255 input bytes. Ctrl-C is a separate latch, Ctrl-] exits immediately.
RX_POLL:
        php
        pha
        phx
        lda $7f81
        pha
        and #7
        beq @noerror
        inc RX_ERRORS
@noerror:
        pla
        and #8
        beq @done
        lda $7f80
        and #$7f
        cmp #$1d
        beq @exit
        cmp #3
        beq @break
        pha
        ldx RX_HEAD
        inx
        cpx RX_TAIL
        beq @full
        dex
        pla
        sta RX_RING,x
        inc RX_HEAD
        bra @done
@full:  pla
        inc RX_OVERFLOW
        bra @done
@break: inc BREAK_PENDING
@done:  plx
        pla
        plp
        rts
@exit:  jmp $0600
MONRDKEY_NB:
        jsr RX_POLL
        lda BREAK_PENDING
        beq @normal
        stz BREAK_PENDING
        lda #3
        sec
        rts
@normal:
        phx
        ldx RX_TAIL
        cpx RX_HEAD
        beq @empty
        lda RX_RING,x
        inc RX_TAIL
        plx
        sec
        rts
@empty: plx
        clc
        rts
MONRDKEY:
@wait:  jsr MONRDKEY_NB
        bcc @wait
        rts
MONCOUT:
        php
        pha
        phx
        phy
        sta $7f80
        ; >= 4*(256*5-1) CPU cycles, plus RX polling overhead.
        ; At <=8 MHz: >640 us versus 520.83 us per 19200/8N1 character.
        ldx #4
@outer: jsr RX_POLL
        ldy #0
@inner: dey
        bne @inner
        dex
        bne @outer
        ply
        plx
        pla
        plp
        rts
; Full-line input, printable ASCII; bounded to upstream's 71-byte buffer.
UART_LINE:
        ldx #0
@next:  jsr MONRDKEY
        cmp #3
        bne @notbreak
        ldx #STACK_TOP
        txs
        jmp RESTART
@notbreak:
        cmp #10
        bne @notlf
        lda LAST_CR
        bne @next
        lda #13
@notlf: cmp #13
        beq @enter
        stz LAST_CR
        cmp #8
        beq @erase
        cmp #127
        beq @erase
        cmp #21 ; Ctrl-U: erase line
        beq @kill
        cmp #32
        bcc @next
        cmp #127
        bcs @next
        cpx #71
        bcs @bell
        sta INPUTBUFFER,x
        inx
        jsr MONCOUT
        bra @next
@erase: cpx #0
        beq @next
        dex
        jsr rubout
        bra @next
@kill:  cpx #0
        beq @next
        dex
        jsr rubout
        bra @kill
@bell:  lda #7
        jsr MONCOUT
        bra @next
@enter: lda #1
        sta LAST_CR
        lda #0
        sta INPUTBUFFER,x
        lda #13
        jsr MONCOUT
        lda #10
        jsr MONCOUT
        ldx #<(INPUTBUFFER-1)
        ldy #>(INPUTBUFFER-1)
        rts
rubout: lda #8
        jsr MONCOUT
        lda #32
        jsr MONCOUT
        lda #8
        jmp MONCOUT
