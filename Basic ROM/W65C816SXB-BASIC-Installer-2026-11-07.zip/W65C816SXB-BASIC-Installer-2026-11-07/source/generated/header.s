.segment "HEADER"
.setcpu "65816"
.export EMULATION_ENTRY, ENTRY
ENTRY:
        sei
        clc
        xce
        rep #$20
.a16
        lda #0
        tcd
        sep #$20
.a8
        pha
        plb
        sec
        xce
EMULATION_ENTRY:
.setcpu "65C02"
        cld
        ldx #$ff
        txs
        ; Install the bank-return trampoline before interrupts can reach it.
        ldx #return_end-return_code-1
@copy: lda return_code,x
        sta $0600,x
        dex
        bpl @copy
        jsr INITUSBSERIAL
        jsr EDU_INIT
        ldx #0
@banner:lda banner,x
        beq @ready
        jsr MONCOUT
        inx
        bra @banner
@ready:jmp COLD_START
banner: .byte 13,10,"W65C816 BASIC",13,10,"CTRL-] RETURNS TO WDC MONITOR",13,10,0
return_code:
.setcpu "65816"
        sei
        clc
        xce
        sep #$20
.a8
        lda #0
        pha
        plb
        sec
        xce
        ldx #$ff
        txs
        lda #0 ; verified original VIA2 PCR: bank 3 through pull-ups
        sta $7fec
        jmp $812b ; verified bank-3 reset entry in backed-up WDCMON 2.0.4.3
return_end:
.setcpu "65C02"
