; RAM-only launcher for BASIC in flash bank 0. Load/execute at $0400.
; Candidate: never execute until bank 0 is programmed, read back and approved.
.setcpu "65816"
.segment "CODE"
sei
clc
xce
rep #$20
.a16
lda #0
tcd
sep #$20
.a8
pha
plb
sec
xce
ldx #$ff
txs
ldx #return_end-return_code-1
copy:lda return_code,x
sta $0600,x
dex
bpl copy
lda #$cc ; CA2 and CB2 low: bank 0, preserves neither edge bit (original PCR=$00)
sta $7fec
jmp $8000
return_code:
sei
clc
xce
sep #$20
lda #0
pha
plb
sec
xce
ldx #$ff
txs
lda #0
sta $7fec
jmp $812b
return_end:
