# Interpreter selection and adaptation

Selected [mist64/msbasic](https://github.com/mist64/msbasic), commit `2a0bc2fe0db13f8cf1b5c40b1d5617263cdb9cb4` (2026-04-04). The repository already supplies an SXB adaptation rather than requiring a new interpreter. Its integrated historical Microsoft BASIC tree supports the requested numbered programs, PRINT, INPUT, LET, FOR/NEXT, IF/THEN, GOTO, GOSUB/RETURN, LIST/RUN/NEW/STOP, strings, arrays, PEEK/POKE and normal BASIC arithmetic/functions. The selected CONFIG_2C configuration uses five-byte floating point; it is not native 16-bit integer BASIC.

Existing upstream SXB port: RAM origin $1000, program storage $5000, console over FT245R VIA2 FIFO. Our changes replace that console with real W65C51 I/O, move RAM entry to $2000, and add a ROM build at $8000. Other historical ports were useful references for configuration/layout, but no second interpreter was needed: the existing SXB interpreter fits the hardware and passed both emulation and the physical UART language/prime test. WDC board examples are downloaded separately under hardware for reference and are not linked into this build.

The original clone is unmodified. `tools/prepare_source.py` creates `builds/generated/`, overlays `source/platform/`, then applies explicit startup/input/POKE/prompt changes. All generated assembly is retained for inspection. RAM and ROM builds share language sources and UART driver.

Important fixes and platform decisions:

* Explicit 65816 startup initializes direct page D=0 and data bank DB=0, then enters emulation mode, clears decimal mode, disables IRQ, and initializes the page-1 stack. No undocumented opcodes or 65816 native-width assumptions inside BASIC.
* Upstream SXB ZP_START4=$65 overlaps Z14 and TEMPPT in the full precision configuration. Move it to $66; compile-time assertions check the boundary and copied CHRGET capacity. The out-of-memory ROM test exposed the overlap; it is fixed and retested.
* Enable CONFIG_SAFE_NAMENOTFOUND and CONFIG_PEEK_SAVE_LINNUM. Upstream's one-byte-short random-seed copy is documented in its source and retained; it is not involved in deterministic language tests.
* Replace destructive RAM-size probing with the fixed ceiling $7D00. BASIC never probes monitor RAM or I/O to guess memory size. RAM storage begins $5000; ROM storage $0800. Linker limits enforce code fit.
* A RAM trampoline at $0600 forces a known CPU mode/DB/stack, restores original PCR=$00 and jumps to the observed monitor reset entry $812B. Ctrl-] invokes it. ROM vectors also target it; this route discards the BASIC session rather than resuming it.
* W65C51 command $0B/control $1F. Poll receive status bit 3. Do not poll transmit status bit 4: WDC explicitly documents the TDRE limitation. The driver enforces a transmit interval of at least 5404 modeled CPU cycles, about 675.5 us at 8 MHz, exceeding 520.83 us per 19200/8N1 frame. Hardware waveform timing has not been measured.
* Poll RX during TX waits and execution break checks. Buffer up to 255 bytes, latch Ctrl+C separately, and expose overflow/error counters at $0204/$0205. This is bounded buffering, not an unlimited paste queue. Use paced file/paste transfers (5 ms/character, 20 ms/line).
* Custom line input supports printable ASCII, BS, Delete, Ctrl-U, CR, LF, and CRLF. Lines are limited to 71 characters. Keywords must be UPPERCASE; lowercase characters are preserved for string data.
* READY prompt and banner are customized. The initial build confined POKE to scratch $0400–$04FF; the current EDU build also permits PIA/VIA1 $7FA0–$7FDF. POKE is confined to these reviewed regions; invalid targets produce ILLEGAL QUANTITY. UART, monitor/flash-bank-control and ROM writes remain rejected by POKE. PEEK is available, but reading hardware registers can have device side effects. LOAD/SAVE explicitly produce ILLEGAL QUANTITY because no storage transport is implemented.
* Correct Ctrl+C entry flags (Z=1, C=1) before falling into upstream STOP. Emulation caught the initial wrong flag handling before the physical build was loaded.

## License and redistribution

Upstream README declares **2-clause BSD** and credits Michael Steil and other contributors. Keep that README, attribution, source notices and any applicable copyright/license terms with source distributions. Binary redistribution under BSD-2-Clause ordinarily requires copyright notice, conditions and disclaimer in accompanying documentation. The cloned tree does not contain a standalone complete LICENSE with an unambiguous historical Microsoft grant; do not invent one or represent the README as a legal opinion. Resolve that provenance/notice issue before public commercial or binary redistribution. Personal local building and testing is the current scope.

WDC PDFs and original firmware retain WDC's rights. WDC-Board-Projects carries GPL-3.0 and is a reference-only download; its source is not combined into the interpreter. cc65 license is retained in tools/cc65-LICENSE. Python dependencies retain their own distribution metadata/licenses in the environment. No external publication was performed.

## Permanent EDU/WAIT revision

source/platform/edu.s adds native USR services with private RAM0220+, controlled 24-bit access only to banks08–0F, PIA LED/buzzer, I2C with open-drain direction switching, SPI and bounded pin/bank/select handling. Startup binds USR to EDU_USR after BASIC initialization. No BASIC parser executes on the PC. WAIT now accepts milliseconds0–65535; its timed loop polls UART twice per millisecond and honors Ctrl+C. The exact WAIT1000 interval modeled8,000,015 CPU cycles at8 MHz; physical USB/BRK timing confirmed approximately1 second. User confirmed one-second LED blinking from ROM. All original language regression checks passed again for the current RAM/ROM images. See docs/EDU-BASIC.md.
