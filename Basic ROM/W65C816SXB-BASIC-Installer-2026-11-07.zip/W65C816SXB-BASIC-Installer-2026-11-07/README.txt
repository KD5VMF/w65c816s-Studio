W65C816SXB ROM BASIC INSTALLER - 2026-11-07
=========================================

This installs the current EDU + millisecond WAIT BASIC permanently in flash
bank 0. After installation, reconnect your IDE and use its existing BASIC
button. Reset/power-on still enters the original WDC monitor.

QUICK START - WINDOWS

1. Extract the entire ZIP into a writable folder. Do not run inside the ZIP.
2. Python 3.9 or newer is required. If it is not installed, install Python 3
   with the Python launcher enabled. No pip packages or compiler are needed:
   pyserial 3.5 is included. Python itself and the FTDI driver are not bundled.
3. Connect the SXB board's micro-USB programmer connection and power the board
   normally. Windows must show an FTDI USB serial/COM port. If missing, install
   the board's FTDI VCP driver. This is NOT the separate EDU UART connection.
4. Close the IDE/debugger's board connection and any other application using
   that USB programmer port. Press the physical RESET button on the board.
5. Double-click INSTALL-BASIC.bat. Choose the SXB FT245R programmer COM port.
6. The installer checks compatibility and saves TWO matching full flash
   backups. When prompted, type INSTALL. Keep USB/power connected until SUCCESS.
7. Close the installer, reopen/reconnect the IDE, and press your BASIC button.
   The interpreter stays in ROM across power cycles; the IDE starts it again.

LINUX / macOS

Python 3.9+ is required; the serial dependency is bundled for offline use.
Extract the ZIP, connect the board, close the IDE connection and press RESET.
In a terminal in the extracted folder, run:

    python3 install.py

Or use: sh INSTALL-BASIC.command
On macOS the command file can also be opened if local security settings permit.
If Linux denies access to the USB serial port, use your distribution's serial
port permission setup (often dialout group membership), then log in again.
Do not select the EDU UART adapter. A wrong port stops at the handshake.

SUPPORTED BOARDS AND WHAT THE INSTALLER DOES

Only WDC W65C816SXB with the supported original 2014 WDCMON image, original
flash bank controls, and SST39SF010A flash (ID BF/B5). The exact supported
monitor SHA-256 is in manifest.json. Different monitor/flash versions stop;
this release does not claim compatibility with all SXB firmware revisions.
EDU services assume the documented SXB/EDU wiring and an 8 MHz CPU clock.
The EDU UART is the BASIC console; see docs/HARDWARE.md for wiring.

Supported bank 0 starting states:
  - Completely blank: install BASIC without any erase.
  - This project's first v1 BASIC: erase ONLY bank 0 sectors 0, 1, 2 and update.
  - This exact EDU/WAIT BASIC already installed: verify and finish without writing.
Unrecognized or partially programmed bank 0 contents stop without erase/program.
There is no force switch, whole-chip erase, or automatic retry.

The installer reads all 128 KB twice before asking to install. It verifies the
chip ID, verifies RAM helpers before execution, checks all four banks after
each erase/program, and performs a final full readback. Banks 1, 2 and 3 are
preserved byte for byte. The original monitor is neither bundled nor replaced.

BACKUPS AND RECOVERY

Keep the backups folder! Each run has its own timestamped directory containing
both original 128 KB captures, their SHA-256 values, and a journal. A successful
installation also saves the installed 128 KB readback. Copy this directory to
separate storage. These captures are from YOUR board, not someone else's ROM.

If a write fails or power is interrupted: keep backups/journal, stop the tool,
restore stable power and press RESET to return to the preserved monitor. A
partially programmed BASIC will be refused by the installer. Do not repeatedly
run it or try a whole-chip erase. Provide the journal and your backup to the
board/project maintainer for a bank-0-only recovery. Automatic restore is not
included; the low-level eraser is deliberately limited to three code sectors.

If the failure happened before erase/program, correct the connection/reset/
permissions issue and run again. An unsupported monitor/chip needs a compatible
installer; selecting another COM port will not make that firmware supported.

OPTIONAL COMMANDS (Windows: replace python3 with py -3)

    python3 install.py --check-package
        Offline file/dependency check; never opens a USB port.
    python3 install.py --port COM4 --check
        Back up/check board, with no flash identify/erase/program commands.
    python3 install.py --port /dev/ttyUSB0
        Select a programmer port explicitly and install interactively.
    python3 install.py --backups /path/to/my-backups
        Choose a writable backup location.
    python3 install.py --port COM4 --launch
        Optional verified ROM launch if the IDE is unavailable; no programming.
        First close IDE's connection and RESET the board. Launch uploads only
        RAM helpers and the 59-byte bank launcher, not the BASIC interpreter.

USING BASIC

The IDE's existing BASIC button remains the normal way to start it. If your
IDE needs the ROM launcher, images/launcher.bin is 59 bytes, loaded/executed at
RAM $0400; it selects flash bank 0 and enters BASIC at $8000. The optional
--launch command supplies this path without requiring project history files.

BASIC terminal on the separate EDU ACIA UART: 19200 baud, 8N1, no flow control,
local echo OFF. For pasted programs: 5 ms/character and 20 ms/line. Expect
W65C816 BASIC, 29951 BYTES FREE, READY. Use UPPERCASE keywords.

    PRINT "HELLO WORLD"
    10 PRINT "HELLO FROM ROM"
    20 WAIT 1000
    30 GOTO 10
    RUN

Ctrl+C stops a program; Ctrl+] returns to the monitor; RESET is the fallback.
WAIT 1000 pauses one second at 8 MHz. Interpreter LOAD/SAVE are not implemented.
The examples folder contains LED, OLED, I2C and other EDU programs; hardware
details and known peripheral limits are described in docs/EDU-BASIC.md.

CONTENTS AND PROVENANCE

images/       Exact tested 32 KB BASIC ROM plus optional 59-byte launcher.
helpers/      Precompiled, bounded RAM flash/read helpers. No assembler needed.
vendor/       pyserial 3.5 for Windows/Linux/macOS (unchanged Python sources).
source/       BASIC sources, platform changes, generated assembly and helpers.
licenses/     Upstream notices, dependency license and existing provenance notes.
manifest.json SHA-256 checksums and supported monitor identity.

ROM SHA-256:
7723711edd12be419fbe5fc19172bece989e674aba880793ebd3454ea5cbd2ce

The ROM and existing program/erase helpers were tested on the project board.
The portable installer is verified offline and with simulated transactions;
Windows/macOS USB operation and installation on additional boards have not
been physically tested. Checksums detect damaged/mismatched package files;
they are not a digital signature.

Retain the included upstream credits and notices. Upstream msbasic declares
2-clause BSD; the repository's existing historical license/provenance caveat
is preserved in licenses/interpreter-provenance.md. This archive does not
claim to resolve that caveat or grant rights to WDC's original firmware.
