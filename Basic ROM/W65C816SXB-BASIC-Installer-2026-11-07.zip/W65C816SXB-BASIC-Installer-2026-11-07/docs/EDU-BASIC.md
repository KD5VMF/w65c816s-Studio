# EDU hardware from BASIC, and millisecond WAIT

The EDU build exposes PIA/VIA GPIO directly and a small native bus-service API through standard Microsoft BASIC `USR(0)`. All services execute on the board; the terminal performs no translation. Flash-bank control, UART configuration, monitor workspace and flash remain outside BASIC POKE's allowed range.

## WAIT

```basic
10 PRINT "START"
20 WAIT 1000
30 PRINT "ONE SECOND LATER"
```

WAIT now takes a single millisecond count (0–65535). The historical `WAIT address,mask` meaning is replaced as requested. At the documented 8 MHz CPU clock, WAIT 1000 measured 8,000,015 emulated CPU cycles, or 1.000001875 seconds. Actual RAM routine timings were approximately 1.023 s and 2.030 s via USB/monitor, including protocol latency; the zero-delay baseline was 0.032 s. Timing is intended as a millisecond BASIC delay, not a calibrated laboratory clock. An expression is accepted and converted to an integer. Negative values or values beyond 65535 produce ILLEGAL QUANTITY. Ctrl+C and Ctrl+] remain polled during waits. An independently changed CPU clock requires rebuilding/calibrating the delay.

## Eight LEDs

Direct PIA access, decimal addresses:

```basic
10 POKE 32673,48
20 POKE 32672,255
30 POKE 32673,52
40 POKE 32672,255
50 WAIT 1000
60 POKE 32672,0
70 WAIT 1000
80 GOTO 40
```

Lines 10–30 select the PIA Port-A direction register, set all eight pins as outputs, then select its output register. Writing 0–255 to 32672 sets the LED bit pattern. User visually confirmed the physical BASIC LED flasher. Ctrl+C stops the loop. `POKE 32672,0` turns LEDs off.

## PEEK/POKE permissions

* `$0400–$04FF` (1024–1279): application/service mailbox scratch.
* `$7FA0–$7FDF` (32672–32735): PIA and user VIA, including their hardware mirrors. Enables all EDU GPIO, LED/buzzer control, I2C/SPI, Click pins, ADC ready/RTC interrupt pins and user timers. Device reads can acknowledge/clear device flags; choose addresses intentionally.
* Other POKE targets remain rejected. In particular `$7FE0+` controls the USB monitor and flash banking; `$7F80+` would reconfigure the console. These are protected.

| Register | Hex | Decimal |
|---|---|---|
| PIA Port A data or DDR | 7FA0 | 32672 |
| PIA CRA | 7FA1 | 32673 |
| PIA Port B data or DDR | 7FA2 | 32674 |
| PIA CRB | 7FA3 | 32675 |
| VIA Port B | 7FC0 | 32704 |
| VIA Port A with handshake | 7FC1 | 32705 |
| VIA DDRB | 7FC2 | 32706 |
| VIA DDRA | 7FC3 | 32707 |
| VIA Port A without handshake | 7FCF | 32719 |

PIA Port A drives LEDs; CA2 drives the buzzer. CRA 52 holds buzzer off, 60 turns it on. VIA PA0/PA7 are SCL/SDA; PB0/PB1/PB5 are SPI SCK/MOSI/MISO; PB2 is serial SRAM CS and PB3 is Click CS. Do not drive high on the open-drain I2C lines: the supplied driver releases them through DDR direction bits and waits for clock stretching with a timeout.

## Native service mailbox (ABI 1)

Set command with `POKE 1024,C`, arguments with POKE 1025–1028, then `R=USR(0)`. The function returns an unsigned byte result. `PEEK(1041)` returns status: 0 success, 1 I2C NACK, 2 bad command/address/select, 3 clock-stretch timeout. The byte result is also at 1040.

| Command C | Action | Arguments/result |
|---:|---|---|
| 0 | Query ABI version | Returns 1 |
| 1 | Initialize LED pins and set pattern | 1025=mask; returns mask; buzzer off |
| 2 | Buzzer | 1025=0 off, nonzero on |
| 3 | I2C START/repeated START | Uses VIA PA0/PA7 |
| 4 | I2C STOP | Releases SDA/SCL |
| 5 | I2C transmit byte | 1025=byte; status reports ACK/NACK |
| 6 | I2C read byte, send ACK | Returns byte |
| 7 | I2C read last byte, send NACK | Returns byte |
| 8 | SPI mode-0 initialization | Releases RAM/Click CS, configures MISO input |
| 9 | SPI selection | 1025: 0 neither, 1 SRAM, 2 Click; rejects 3+ |
| 10 | SPI full-duplex transfer | 1025=output byte; returns input byte |
| 11 | Expansion RAM read | 1025=address low,1026=high,1027=bank8–15; returns byte |
| 12 | Expansion RAM write | Same address,1028=value; returns value |

Example LED chase:

```basic
10 POKE 1024,1
20 FOR I=0 TO 7
30 POKE 1025,2^I
40 A=USR(0)
50 WAIT 150
60 NEXT I
70 GOTO 20
```

The controlled 24-bit memory trampoline occupies $0500–$0504; private driver bytes use $0220–$0223 and WAIT uses $0240–$0242. They do not overlap the UART ring, BASIC zero page or the recovery trampoline. Expansion-RAM commands reject CPU banks outside $08–$0F, preventing access through aliases to SXB RAM/flash.

## Programs

All examples are in `tests/edu/`. NEW before loading a different numbered program; use uppercase keywords and paced terminal transfer.

* `led-flash.bas`, `led-chase.bas`, `buzzer.bas`: visible/audible outputs, with WAIT timing.
* `i2c-scan.bas`: decimal addresses; expected observed addresses 60,87,96,111 (hex 3C,57,60,6F).
* `rtc.bas`: reads MCP79411 time/date without changing it. Physical read succeeded, but current RTC oscillator is stopped and time is 00:00:00. Starting/setting a battery-backed clock is a separate operation; no time/EEPROM write was performed.
* `oled.bas`: SSD1306 128x32 text demo with uppercase/digit font. `oled-64.bas` sets 128x64 geometry. No display-ID read distinguishes these modules, so choose the matching height. Initialization explicitly disables fade/blink, scrolling and zoom, keeps the screen off while clearing/drawing, then enables it, and uses the documented VCOM setting. The physical display acknowledged all data and the user saw the words, but reported flashing/blanking in both geometry trials. The full effect-reset program is under visual test; ACK is not a visual-stability pass.
* `temperature.bas`: ADS1015 single-ended AIN2, ±2.048 V range/1 mV step, MCP9700A (mV−500)/10 °C. The ADC **did not ACK** at 48–4B even after bus recovery; the example reports ADC NOT FOUND instead of inventing a temperature. Firmware supports the protocol, but this board's ADC presence/power/address/wiring needs physical investigation. A working ADC temperature measurement has not been claimed.
* `spi-sram.bas`: reads byte 0, saves it, tests 90, restores the original and verifies. Physical native-driver test passed (19→90→19). Avoid interrupting a save/test/restore routine mid-write if the old byte matters.
* `expansion-ram.bas`: save/test/restore address $7000 in banks8–15. Actual hardware native-driver test verified eight distinct patterns and restored all eight saved bytes. This establishes bank access, not a full 512 KB March test. Power-off loses ordinary parallel SRAM contents.
* `gpio.bas`: reads external PIA Port B with pins configured as inputs. Click/Grove/QWIIC/OLED devices use the same exposed PIA/VIA/buses. No particular external module is assumed attached.
* `crypto-info.bas`: read-only ATECC608A wake/revision example using the generic I2C services and a verified Info packet CRC. No key provisioning, configuration writes or irreversible lock operations are issued. The chip acknowledged at 60; the full BASIC Info example is supplied but has not been reported run physically. Generic I2C access is available for further device-specific commands.
* `system-info.bas`: BASIC memory and EDU ABI information.

The MCP79411 EEPROM at 57 is reachable through the generic I2C API; only its address was probed. No EEPROM data or crypto configuration was changed. The SPI battery-backed SRAM is data storage, not a BASIC filesystem: interpreter LOAD/SAVE integration remains future work.

## Evidence and sources

`builds/edu-hardware-tests.json` records actual I2C ACKs, SPI byte save/test/restore and eight-bank RAM save/test/restore. `builds/edu-peripheral-results.json` records actual RTC bytes, ADC NACKs and OLED ACK count. `builds/edu-emulator-results.json` checks BASIC USR binding, PIA/VIA permissions, invalid commands, long-address bounds and LED/buzzer sequences. `builds/wait-*` records timing/range/interruption checks. Hardware observations and emulator results are separate.

Primary references: WDC EDU schematic/datasheet in hardware; [TI ADS1015](https://www.ti.com/lit/ds/symlink/ads1015.pdf), [Microchip MCP9700A](https://www.microchip.com/en-us/product/MCP9700A), [Microchip 23LCV1024](https://ww1.microchip.com/downloads/aemDocuments/documents/OTH/ProductDocuments/DataSheets/25156A.pdf), and Microchip's [CryptoAuthLib Info implementation](https://github.com/MicrochipTech/cryptoauthlib/blob/main/lib/calib/calib_info.c). CryptoAuthLib code was consulted for protocol facts and is not linked into BASIC.
