# Monitor protocol and launch

This board's original WDCMON is a binary debugger server on the USB FT245R interface. It does not print a human monitor prompt on the UART. BASIC does use the UART. Preserving that distinction is necessary to retain the existing firmware unchanged.

Before each operation, host sends bytes `55 AA`; monitor responds `CC`. Complete the command after a successful handshake; leaving the monitor waiting for a command and then issuing another handshake can desynchronize it. Do not blindly retry command bytes into an uncertain protocol state. Press physical RESET if the transport cannot synchronize.

Verified operations:

* `00`: benign resync response `00` (tested during discovery).
* `02`: host-to-memory transfer. Three-byte little-endian CPU address, two-byte little-endian length, then data. Our tools restrict writes to $0200–$7CFF or the exact 16-byte CPU context.
* `03`: memory-to-host transfer. Same address and length fields, then read exactly that many bytes.
* `05`: execute the saved debug context. The context is at $7E00, layout six little-endian 16-bit values A/X/Y/PC/D/S, then four bytes P/E/PB/DB. Launch uses PC=$2000,D=0,S=$01FF,P=$34,E=1,PB=DB=0.
* Uploaded diagnostics returned via BRK; the observed notification is `02`. Software monitor reset/physical reset notifications must be checked separately.

The 2023 WDCMON manual lists newer commands 06–0D including flash operations and library vectors F800+. Their semantics/availability have NOT been established for this 2014 firmware. No tools here issue them. In particular, **do not assume command 09 is safe or selects one bank**.

## Exact verified RAM launch on MIND

With the board at the monitor:

```sh
cd /home/sysop/w65c816-basic
python3 tools/load_ram.py --run
```

This writes the RAM image at $2000, reads it back byte for byte, writes/reads back the CPU context, then sends execution command 05. Tera Term on the separate ACIA connection receives BASIC at 19200/8N1. No PC translates BASIC commands.

Ctrl-] requests a fresh WDCMON session through RAM $0600. It is intended to preserve flash and discard BASIC state. Physical RESET is the fallback. Do not call the RAM loader while BASIC is running; return to monitor or reset first. Current code and context are volatile across power-off.

## Installed ROM launch

At original monitor:

```sh
python3 tools/launch_rom.py
```

The script validates bank3's original image and current bank0's installed hash, uploads RAM verification helpers and the59-byte launcher at0400, and executes flash entry8000. The interpreter itself is not uploaded. The launcher installs0600 recovery, selects bank0, then jumps8000. Ctrl+] returns to original monitor. User-reported reboot was followed by successful monitor/ROM verification and relaunch. Full power-removal testing is not independently asserted merely from a reported reboot.

No monitor firmware patch or permanent human command was installed. The launcher is volatile and supplied by MIND per power cycle; BASIC remains in flash. Canonical launcher/launcher.bin and current rom-images/basic-bank0.bin are installed artifacts, not blank-bank candidates. The general RAM loader remains limited to2000 to prevent accidental alternate-entry execution.
