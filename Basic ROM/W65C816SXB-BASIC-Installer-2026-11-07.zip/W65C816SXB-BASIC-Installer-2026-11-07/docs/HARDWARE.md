# Hardware findings — 2026-11-07

Current installation: SST39SF010A was positively identified by BF/B5 software ID twice after explicit write approval. BASIC + EDU ABI1 + millisecond WAIT is installed in bank0; banks1–3 match original backups. Original bank0/1 blank observations below describe the initial capture. See docs/FLASH-PLAN.md and builds/flash-installation.json. The board revisions/CPU oscillator marking remain uninspected.


## Observed on the connected board

* MIND exposes FTDI FT245R USB FIFO serial `AB0NYFCX`, `/dev/serial/by-id/usb-FTDI_FT245R_USB_FIFO_AB0NYFCX-if00-port0` (currently `/dev/ttyUSB0`). USB VID/PID 0403:6001. This is the programmer/debug FIFO, not the W65C51 UART. The host serial API uses 115200/8N1; the FT245R is a parallel FIFO so this host setting does not establish ACIA baud.
* `/dev/ttyACM0` is Analog Devices PlutoSDR. Do not use it for this project. Linux also creates `/dev/ttyS*` nodes; creation alone does not establish a connected UART. No ACIA USB adapter was enumerated on MIND. User confirms EDU UART connected to a Windows PC running Tera Term.
* Monitor responds to `55 AA` with `CC`. Memory load/read/debug execute (`02/03/05`) worked, with byte-for-byte verification of uploaded diagnostics and BASIC.
* Backed-up bank 3 contains `WDC65c816SK WDCMON Version =  2.0.4.3`, date `Wed Mar 26 2014  2:46`. Reset vector `$FFFC` contains `$812B`. Monitor data/code starts at `$8000`, unlike newer documentation's `$F000` description. Never assume modern library vectors `$F800+` exist on this firmware.
* VIA2 PCR `$7FEC` initially `$00`. RAM-resident reads using PCR `$CC/$CE/$EC/$EE` selected four flash windows; original PCR was restored before every BRK to monitor. All banks were captured twice and matched.
* Banks 0 and 1: all 32,768 bytes `$FF` in both passes. Bank 2: 256 non-FF bytes, preserve it. Bank 3: 1,525 non-FF bytes including monitor and vectors, preserve it. Blank is an observed byte state, not proof of intended ownership or programming compatibility.
* ACIA command/control read back `$0B/$1F`. Before correcting modem-input wiring status was `$60` after TX; afterward `$10`. User confirmed the 19200/8N1 greeting on Windows. The physical BASIC full test subsequently reported 168 primes, sum 76127, ALL TESTS PASS.
* Three loop timing runs: 1.341469, 1.342154, 1.341824 s for 10,535,231 loop cycles plus startup, BRK, USB and monitor overhead. Apparent rates 7.849–7.854 MHz. Consistent with documented 8 MHz, not a direct oscillator/frequency-counter measurement.

## Documented design, installed details still unconfirmed

Official SXB datasheet specifies W65C816S at 8 MHz, 32 KiB SRAM and 128 KiB flash. Rev-C schematic identifies U1 W65C816S6PLG-14 and U14 SST39SF010A, with socketed 32-pin PLCC flash. **Installed CPU marking, SXB revision, EDU revision and oscillator marking have not been inspected.** The user reported SST markings first as `39F010a`, then `29sf010a`, and confirmed the selected chip was right. Manufacturer SST was user-confirmed; subsequent physical software identification BF/B5 resolved the part as SST39SF010A. Rev C is the downloaded drawing revision, not an observation of this board.

Official EDU Rev-D schematic includes 512 KiB parallel SRAM, 128 KiB serial SRAM, RTC, ADC, temperature sensor and expansion connectors. The 2021 EDU PDF memory table describes banks 01–08; WDC's later getting-started guide explicitly says **08–0F**. Use the latter as the provisional expansion map and verify before any access. Subsequent native-driver tests verified distinct bytes at address7000 in each of banks08–0F and restored all saved bytes. BASIC exposes this memory through controlled USR services; its ordinary program heap remains in bank0 RAM.

## Memory map

All BASIC addresses below are in CPU bank `$00` (flash bank selection is separate from 65816 PBR/DBR).

| Address | Use |
|---|---|
| 0000–00FF | BASIC direct-page variables, input buffer, copied CHRGET; D=0 |
| 0100–01FF | 6502 emulation stack and upstream formatting scratch |
| 0200–0205 | RX head/tail, break latch, CR state, overflow/error counters |
| 0300–03FF | 255-byte-capacity UART RX ring |
| 0400–04FF | POKE/mailbox scratch; ROM launcher uses0400 before BASIC starts |
| 0500–0504 | Controlled LDA/STA-long trampoline for expansion RAM |
| 0600–06FF | RAM monitor-return/interrupt trampoline |
| 0800–7CFF | ROM build program/variables/string storage (free count initially 29951) |
| 2000–447B | Current RAM interpreter image (9340 bytes); see linker map after rebuild |
| 5000–7CFF | RAM build program/variables/string storage (free count initially 11519) |
| 7D00–7EFF | Reserved conservatively for monitor/context/shadow vectors; not BASIC storage |
| 7E00–7E0F | Observed monitor CPU context A,X,Y,PC,D,S (16-bit LE), P,E,PB,DB |
| 7F00–7F1F | XCS0 |
| 7F20–7F3F | XCS1 |
| 7F40–7F5F | XCS2 |
| 7F60–7F7F | XCS3 |
| 7F80–7F9F | W65C51 ACIA, four registers mirrored |
| 7FA0–7FBF | W65C21 PIA |
| 7FC0–7FDF | User W65C22 VIA |
| 7FE0–7FFF | W65C22 VIA2, programmer interface and flash select |
| 8000–FFFF | Selected 32 KiB flash overlay |

ACIA `$7F80`: RX data read / TX data write; `$7F81`: status read / programmed reset write; `$7F82`: command; `$7F83`: control. Command `$0B` enables DTR, RTS, no parity/echo or RX/TX IRQ. Control `$1F` selects 19200 from the 1.8432 MHz reference, 8 data bits, one stop bit and internal receiver clock. IRQ remains disabled in BASIC; RX is polled.

VIA1 base `$7FC0`; VIA2 base `$7FE0`. Standard VIA offsets: ORB 0, ORA 1, DDRB 2, DDRA 3, ACR B, PCR C, IFR D, IER E, ORA-no-handshake F. Bank-select PCR is `$7FEC`, not ORB. CA2=FA15 (flash A15); CB2=FAMS (flash A16). Manual output low/high modes are 110/111 in CA2 bits 3:1 and CB2 bits 7:5.

| Flash bank | CB2/CA2 | PCR with original edge bits 0 | Physical offsets |
|---|---|---|---|
| 0 | 0/0 | CC | 00000–07FFF |
| 1 | 0/1 | CE | 08000–0FFFF |
| 2 | 1/0 | EC | 10000–17FFF |
| 3 | 1/1 | EE | 18000–1FFFF |

Original PCR `$00` leaves these pins as inputs; pull-ups select bank 3. A hardware reset resets VIA control and is designed to restore bank 3. Physical reset/cold-boot behavior must still be explicitly tested. All bank switching must execute in RAM. The backup routine changes only PCR and application RAM; no flash command sequences were issued.

## UART electrical connection

EDU I/O is 5 V logic; the Grove UART is not an RS-232 voltage-level interface. An adapter must accept the board's logic levels; a real RS-232 port needs a suitable transceiver. Adapter model and exact user-installed wiring remain unrecorded.

Official J4 10-pin ACIA pinout: 1 +5V, 2 GND, 3 RTSB, 4 DTRB, 5 RXD, 6 DSRB, 7 TXD, 8 DCDB, 9 CTSB, 10 RXC. EDU has 10k pull-ups on CTSB/DCDB/DSRB. For a three-wire console, those input signals need valid asserted levels; high CTS disables TX. With board power off and no competing driver, pins 6/8/9 can be tied to GND. User corrected wiring and confirmed the greeting; exact wiring was not independently inspected.

## Primary sources

Local PDFs/text extractions are in `hardware/`. Source links:

* [WDC SXB datasheet](https://www.westerndesigncenter.com/wdc/documentation/W65C816SXB.pdf)
* [WDC SXB Rev-C schematic](https://www.westerndesigncenter.com/wdc/Schematics/W65C816SXB.pdf)
* [EDU datasheet](https://www.wdc65xx.com/wdc/documentation/W65C816EDU.pdf)
* [EDU Rev-D schematic](https://www.wdc65xx.com/wdc/Schematics/Schematic_W65C816EDU_REVD.pdf)
* [EDU getting-started corrections](https://wdc65xx.com/getting-started/w65c816edu-getting-started/)
* [WDCMON v2 manual](https://www.westerndesigncenter.com/wdc/documentation/WDCMON_User_Manual_v20.pdf)
* [W65C51N datasheet, March 2024](https://www.westerndesigncenter.com/wdc/documentation/w65c51n.pdf)
* [W65C22 datasheet](https://www.westerndesigncenter.com/wdc/documentation/w65c22.pdf)
* [W65C816S datasheet](https://www.westerndesigncenter.com/wdc/documentation/w65c816s.pdf)
* [Microchip SST39SF010A/020A/040 datasheet](https://ww1.microchip.com/downloads/aemDocuments/documents/MPD/ProductDocuments/DataSheets/SST39SF010A-SST39SF020A-SST39SF040-Data-Sheet-DS20005022.pdf)
* [Official WDC board examples](https://github.com/WesternDesignCenter/WDC-Board-Projects), downloaded separately for reference; not linked into BASIC.

## Subsequent EDU bus observations

I2C address probes returned ACK at3C (OLED),57 (RTC EEPROM),60 (crypto),6F (RTC). Serial SRAM byte0 read19, tested90, then restored19. Parallel RAM banks08–0F returned eight distinct test patterns and the eight original bytes were restored. RTC raw bytes were00000001010101: readable but oscillator stopped. ADS1015 did not ACK at48–4B in the initial scan or after nine-clock bus recovery. No temperature is inferred from absent ADC data. OLED bytes were acknowledged and the user saw words, but a reported flicker/blanking remains under display-initialization investigation; I2C ACK alone is not a display-quality pass.
