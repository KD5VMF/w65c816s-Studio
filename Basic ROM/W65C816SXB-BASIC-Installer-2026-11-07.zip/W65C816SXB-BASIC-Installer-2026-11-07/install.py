#!/usr/bin/env python3
"""Standalone W65C816SXB ROM BASIC installer; distributed by make_install_zip.py."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
NEW = '7723711edd12be419fbe5fc19172bece989e674aba880793ebd3454ea5cbd2ce'
OLD = 'b5c78e366bfba30b19e584aa01043c8dcb8499ff25ebe92ae80066e5090e328c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def check_package():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for name, digest in manifest['files'].items():
        if sha((ROOT / name).read_bytes()) != digest:
            raise RuntimeError('Package file failed checksum: ' + name)
    if sha((ROOT / 'images/basic-bank0.bin').read_bytes()) != NEW:
        raise RuntimeError('Wrong BASIC release')
    import serial
    if serial.VERSION != '3.5':
        raise RuntimeError('Bundled pyserial 3.5 missing')
    return manifest


class Monitor:
    def __init__(self, port):
        import serial
        options = {'exclusive': True} if os.name == 'posix' else {}
        self.s = serial.Serial(port, 115200, timeout=5, write_timeout=5, **options)

    def close(self):
        self.s.close()

    def sync(self):
        self.s.write(b'\x55\xaa')
        self.s.flush()
        for _ in range(8):
            value = self.s.read(1)
            if value == b'\xcc':
                return
            if value not in (b'\xff', b'\x02', b'\x07'):
                break
        raise RuntimeError('No WDCMON handshake. Close the IDE, press board RESET, and try again.')

    def read(self, addr, size):
        if not (0 <= addr and 0 < size <= 65535 and addr + size <= 65536):
            raise ValueError('Invalid memory read')
        self.sync()
        self.s.write(b'\x03' + addr.to_bytes(3, 'little') + struct.pack('<H', size))
        self.s.flush()
        data = self.s.read(size)
        if len(data) != size:
            raise RuntimeError('Incomplete USB read; stopped without retry')
        return data

    def write(self, addr, data):
        if not ((0x200 <= addr and addr + len(data) <= 0x7d00) or
                (addr == 0x7e00 and len(data) == 16)):
            raise ValueError('Only application RAM/context writes allowed')
        self.sync()
        self.s.write(b'\x02' + addr.to_bytes(3, 'little') + struct.pack('<H', len(data)) + data)
        self.s.flush()
        if self.read(addr, len(data)) != data:
            raise RuntimeError('RAM verification failed')

    def load(self, code, addr=0x2000):
        self.write(addr, code)
        self.write(0x7e00, struct.pack('<6H4B', 0, 0, 0, addr, 0, 0x1ff, 0x34, 1, 0, 0))

    def run(self):
        self.sync()
        self.s.write(b'\x05')
        self.s.flush()

    def execute(self, name):
        self.load((ROOT / 'helpers' / (name + '.bin')).read_bytes())
        self.run()
        if self.s.read(1) != b'\x02':
            raise RuntimeError('RAM helper did not return. STOP; see recovery instructions.')


def read_bank(m, bank):
    if bank not in range(4) or m.read(0x7fec, 1) != b'\x00':
        raise RuntimeError('Expected original monitor bank state; press RESET')
    data = bytearray()
    for chunk in range(4):
        m.execute(f'read-{bank}-{chunk}')
        if m.read(0x7fec, 1) != b'\x00':
            raise RuntimeError('Flash bank state was not restored')
        data.extend(m.read(0x3000, 8192))
    return bytes(data)


def read_full(m):
    return b''.join(read_bank(m, bank) for bank in range(4))


def install_plan(before, target):
    if len(before) != 32768 or len(target) != 32768 or sha(target) != NEW:
        raise RuntimeError('Invalid ROM image')
    if before == target:
        return [], []
    if before == b'\xff' * 32768:
        return [], [0, 1, 2, 3]
    if sha(before) == OLD:
        # The existing bounded programmer requires an entire 8 KB blank chunk.
        erased = bytearray(before)
        for sector in range(3):
            erased[sector * 4096:(sector + 1) * 4096] = b'\xff' * 4096
        if erased[:16384] != b'\xff' * 16384 or before[16384:] != target[16384:]:
            raise RuntimeError('Unsupported old ROM layout')
        return [0, 1, 2], [0, 1]
    raise RuntimeError('Bank 0 contains unrecognized data. Nothing erased. Keep the backup; contact support.')


def choose_port():
    from serial.tools import list_ports
    ports = sorted(list_ports.comports(), key=lambda p: p.device)
    print('\nSelect the SXB micro-USB / FT245R programmer port (not the EDU UART):')
    for index, port in enumerate(ports, 1):
        print(f'  {index}. {port.device} - {port.description} [{port.hwid}]')
    answer = input('Port number, or full port name: ').strip()
    if answer.isdigit() and 1 <= int(answer) <= len(ports):
        return ports[int(answer) - 1].device
    if not answer or answer.isdigit():
        raise RuntimeError('No valid port selected')
    return answer


def install(m, manifest, backup_root, verify_only=False):
    if m.read(0x7fec, 1) != b'\x00':
        raise RuntimeError('Board must be at original WDCMON; press RESET')
    if sha(m.read(0x8000, 32768)) != manifest['supported_monitor_sha256']:
        raise RuntimeError('Unsupported monitor firmware. No flash commands sent. This release needs the supported 2014 WDCMON.')
    target = (ROOT / 'images/basic-bank0.bin').read_bytes()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    out = backup_root / stamp
    out.mkdir(parents=True, exist_ok=False)
    journal = {'status': 'backing-up', 'port': m.s.port, 'events': []}

    def log(message, **details):
        print(message, flush=True)
        journal['events'].append({'message': message, **details})
        (out / 'journal.json').write_text(json.dumps(journal, indent=2) + '\n')

    try:
        log('Reading all four flash banks twice. Keep power and USB connected...')
        first = read_full(m)
        (out / 'flash-128k-read1.bin').write_bytes(first)
        second = read_full(m)
        (out / 'flash-128k-read2.bin').write_bytes(second)
        if first != second:
            raise RuntimeError('Backup reads differ; no erase/program performed')
        backup_manifest = {f'flash-128k-read{n}.bin': sha(first) for n in (1, 2)}
        (out / 'backup-sha256.json').write_text(json.dumps(backup_manifest, indent=2) + '\n')
        log('Matching full backups saved: ' + str(out))
        if sha(first[98304:]) != manifest['supported_monitor_sha256']:
            raise RuntimeError('Backup monitor mismatch')
        sectors, chunks = install_plan(first[:32768], target)
        if not chunks:
            journal['status'] = 'already-installed'
            log('Current BASIC already installed and verified. Use your IDE BASIC button.')
            return
        if verify_only:
            journal['status'] = 'check-only'
            log('Compatible board. BASIC can be installed.', erase_sectors=sectors, program_chunks=chunks)
            return
        print('\nInstall BASIC into flash bank 0. Banks 1, 2 and the original monitor are preserved.')
        print('Do not unplug or reset during installation. Your backup is saved above.')
        if input('Type INSTALL to continue, or press Enter to cancel: ').strip() != 'INSTALL':
            journal['status'] = 'cancelled'
            log('Cancelled before flash identification/erase/program.')
            return
        m.execute('identify-39')
        if m.read(0x2800, 2) != b'\xbf\xb5':
            raise RuntimeError('Expected SST39SF010A chip ID BF/B5; refusing erase/program')
        if read_full(m) != first:
            raise RuntimeError('Flash changed after backup/ID; refusing erase/program')
        expected = bytearray(first)
        journal['status'] = 'installing'
        for sector in sectors:
            log(f'Erasing bank 0 sector {sector} only...')
            m.execute(f'flash-erase-{sector}')
            result = m.read(0x2800, 8)
            if result[0] != 0 or result[7] != 0x53:
                raise RuntimeError('Sector erase failed: ' + result.hex())
            expected[sector * 4096:(sector + 1) * 4096] = b'\xff' * 4096
            if read_full(m) != expected:
                raise RuntimeError('Full flash verification failed after erase')
        for chunk in chunks:
            payload = target[chunk * 8192:(chunk + 1) * 8192]
            m.write(0x3000, payload)
            log(f'Programming bank 0 block {chunk + 1}/4...')
            m.execute(f'flash-program-{chunk}')
            result = m.read(0x2800, 8)
            if (result[0] != 0 or result[7] != 0x53 or
                    int.from_bytes(result[5:7], 'little') != sum(v != 255 for v in payload)):
                raise RuntimeError('Flash programming failed: ' + result.hex())
            expected[chunk * 8192:(chunk + 1) * 8192] = payload
            if read_full(m) != expected:
                raise RuntimeError('Full flash verification failed after programming')
        final = read_full(m)
        if final != target + first[32768:]:
            raise RuntimeError('Final flash readback mismatch')
        (out / 'flash-128k-installed.bin').write_bytes(final)
        journal['status'] = 'installed-and-verified'
        log('SUCCESS: BASIC installed; all other banks preserved byte for byte. Use your IDE BASIC button.')
    except BaseException as error:
        journal['status'] = 'stopped'
        log('STOPPED. No automatic retry. Keep this backup folder.', error=str(error))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', help='SXB USB programmer port, e.g. COM4 or /dev/ttyUSB0')
    parser.add_argument('--check-package', action='store_true', help='Offline checks; never opens a board')
    parser.add_argument('--check', action='store_true', help='Back up and inspect board; no flash ID/erase/program')
    parser.add_argument('--backups', type=Path, default=ROOT / 'backups')
    parser.add_argument('--launch', action='store_true', help='Verify ROM and start BASIC without flash programming')
    args = parser.parse_args()
    if args.check and args.launch:
        parser.error('--check and --launch cannot be combined')
    manifest = check_package()
    if args.check_package:
        print('Package checksums and bundled USB serial dependency OK. No board accessed.')
        return
    print('W65C816SXB ROM BASIC installer - EDU + millisecond WAIT')
    print('Close IDE/debugger connections to the SXB USB port and press board RESET first.')
    m = Monitor(args.port or choose_port())
    try:
        if args.launch:
            if (m.read(0x7fec, 1) != b'\x00' or
                    sha(m.read(0x8000, 32768)) != manifest['supported_monitor_sha256'] or
                    sha(read_bank(m, 0)) != NEW):
                raise RuntimeError('Installed ROM/monitor verification failed; launch refused')
            m.load((ROOT / 'images/launcher.bin').read_bytes(), addr=0x400)
            m.run()
            print('BASIC started from ROM. EDU UART: 19200 / 8N1 / no flow control.')
        else:
            install(m, manifest, args.backups.resolve(), verify_only=args.check)
    finally:
        m.close()


if __name__ == '__main__':
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print('\nSTOPPED: ' + str(exc), file=sys.stderr)
        print('Do not retry a failed write. See README.txt; keep the backups and journal.', file=sys.stderr)
        sys.exit(1)
