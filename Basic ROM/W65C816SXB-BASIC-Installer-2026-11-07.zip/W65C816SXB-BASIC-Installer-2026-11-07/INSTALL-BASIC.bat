@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 install.py %*
  goto finished
)
where python >nul 2>nul
if not errorlevel 1 (
  python install.py %*
  goto finished
)
echo Python 3 is required. Install Python 3 with the Python launcher enabled, then run this file again.
:finished
echo.
pause
