# Build button repair — November 7, 2026

This update changes the **Build (F6)**, **Upload only**, and **Build & Run (F5)** build stage. It does **not** change the START BASIC ROM-switch routine or the existing ASM examples.

## Changes

- Locates `ca65.exe`, `ld65.exe`, `board.cfg` and `edu.inc` in both normal Visual Studio build layouts and published layouts.
- Reports the exact missing dependency and paths checked rather than failing without context.
- Logs each assembler/linker invocation and exit status.
- Runs tools in the output folder, waits for completion, and checks that the `.o` and `.bin` files were actually produced.
- Preserves listing output when available, and raises the timeout to 90 seconds.
- Emits a `Build requested` line as soon as you press the button.

## How to test

1. Extract all files from this ZIP; don't launch the executable directly from inside the ZIP.
2. Run `BUILD.cmd` (requires the .NET 10 SDK), or open `W65C816-Studio.sln` in Visual Studio and build Studio.
3. Launch the newly built exe (not an older desktop shortcut).
4. Choose **EDU · 8 LED chase**, click **Build F6**. A COM port is **not** required for Build alone.
5. The **Build output** tab should show `Build requested`, `Running ca65.exe`, `Running ld65.exe`, then `Build succeeded`.
6. If anything fails, the tab will display the specific error. Copy its complete contents for diagnosis.

Note: this source update has been statically inspected, but not compiled with the Windows .NET SDK or tested on the physical SXB. The ROM BASIC launcher is unchanged and remains unverified against Codex's 59-byte launcher.
