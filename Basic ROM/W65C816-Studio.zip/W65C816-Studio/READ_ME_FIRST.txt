W65C816 STUDIO — HIGH-CONTRAST EDITION

The WPF source has been updated for a LIGHT UI WITH BLACK TEXT throughout.

To compile on Windows with the .NET 10 SDK:
  1. Open this Source folder.
  2. Double-click BUILD.cmd.
  3. When publish completes, launch publish\W65C816Studio.exe

The application needs the contents of publish (including copied assets).
The prebuilt EXE from the original ZIP is NOT included here because it still uses the old interface.

CHANGES
- Black text in editor, output, tabs, sidebar, buttons, labels, and syntax highlighting.
- White editing/output backgrounds and pale controls, clearer borders.
- Larger default text, wider left sidebar, taller output panel.
- All features and build/upload behaviors preserved in source.

NOTE: This source revision was not compiled in this environment; build it on Windows.

NEW EDU OLED EXAMPLES
- EDU-OLED-Text.s : Hello World text on an SSD1306 OLED.
- EDU-OLED-512K-RAM-Test.s : Destructive test of RAM banks $08-$0F with OLED progress.
- EDU-OLED-RTC-Clock.s : Edit START_HOUR/START_MINUTE/START_SECOND at the top.

Choose the W65C816SXB + EDU profile, then select the example from the
Examples dropdown and click Open example. Samples are copied to Documents\W65C816 Studio
on first launch if the destination filename does not already exist.
If you modified a sample previously, its existing copy is intentionally not overwritten.
OLED samples assume an SSD1306 128x64 at I2C $3C. The clock initializes the
onboard RTC to the configured time every time it starts.
WARNING: The 512K test overwrites all external expansion RAM in banks $08-$0F.

This updated source was not built or hardware-tested in this environment.

FIX: Build & Run (F5) now runs as explicitly ordered phases: save, assemble, link, upload, verify application and CPU context, then send GO after a short monitor settle delay. Build and Upload only remain separate actions. If an earlier program is still running, press the board RESET / S2 button before starting the next upload. This change has not been tested against physical hardware.

EXAMPLE FIX (November 2026):
Choose examples from the Samples selector then Open Example. Each example now
comes from its own verified file in Documents\W65C816 Studio\Studio Examples - Verified.
Legacy files in the main Documents\W65C816 Studio folder are NOT deleted,
including any former EDU-LEDs.s containing OLED code. The IDE redirects the
last-opened legacy example to its verified counterpart on first launch.
On each launch/open example the verified examples refresh from the bundled
release. If one was modified locally it is copied to Example Backups first.
Use Save As to make a personal version you want to edit permanently.
EDU-LEDs.s = 8 LED chase; EDU-OLED-Text.s = OLED Hello World.

FIND BUTTON FIX (November 2026):
Find now opens the editor search bar and leaves keyboard focus inside its search field.
Ctrl+F invokes the same Find action from anywhere in the IDE.
Type the search phrase and use the search bar navigation (or Enter) to move through matches.
Previously the button called Editor.Focus() after SearchPanel.Open(), stealing focus.

NEW EXAMPLE: Select W65C816EDU profile, then EDU · OLED primes to 1 million.
File: examples/EDU-OLED-Primes-1Million.s (corrected immediate ASCII syntax).
