@echo off
setlocal EnableExtensions
pushd "%~dp0" || (echo ERROR: Cannot open the project directory. & pause & exit /b 1)
title W65C816 Studio - Build and Publish
set "PROJECT=Studio\Studio.csproj"
set "LOGDIR=%CD%\build-logs"
set "OUTDIR=%CD%\publish"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
echo =================================================
echo    W65C816 Studio - Windows x64 Publish
echo =================================================
echo Project directory: %CD%
echo.
if not exist "Core\Studio.Core.csproj" goto missing
if not exist "%PROJECT%" goto missing
if not exist "Studio\MainWindow.xaml.cs" goto missing
if not exist "assets\tools\ca65.exe" goto missingassets
if not exist "assets\tools\ld65.exe" goto missingassets
if not exist "assets\tools\board.cfg" goto missingassets
if not exist "assets\examples\edu.inc" goto missingassets
where dotnet.exe >nul 2>&1
if errorlevel 1 goto nodotnet
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
echo Installed SDKs:
dotnet --list-sdks
if errorlevel 1 goto nodotnet
dotnet --list-sdks | findstr /R /C:"^10\." >nul
if errorlevel 1 goto oldsdk
echo.
echo STEP 1/3: Restoring packages for win-x64...
dotnet restore "%PROJECT%" -r win-x64 -p:SelfContained=true --nologo -v normal > "%LOGDIR%\restore.log" 2>&1
if errorlevel 1 goto restorefail
echo Restore completed.
echo.
echo STEP 2/3: Building Release...
dotnet build "%PROJECT%" -c Release -r win-x64 --self-contained true --no-restore --nologo -v normal > "%LOGDIR%\build.log" 2>&1
if errorlevel 1 goto buildfail
echo Build completed.
echo.
echo STEP 3/3: Publishing standalone single-file EXE...
dotnet publish "%PROJECT%" -c Release -r win-x64 --self-contained true --no-restore -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "%OUTDIR%" --nologo -v normal > "%LOGDIR%\publish.log" 2>&1
if errorlevel 1 goto publishfail
if not exist "%OUTDIR%\W65C816Studio.exe" goto exe_missing
if not exist "%OUTDIR%\examples\edu.inc" if not exist "%OUTDIR%\assets\examples\edu.inc" goto examplesmissing
if not exist "%OUTDIR%\tools\ca65.exe" if not exist "%OUTDIR%\assets\tools\ca65.exe" goto toolsmissing
echo.
echo SUCCESS: "%OUTDIR%\W65C816Studio.exe"
echo Bundled examples and assembler tools verified.
echo Build logs: "%LOGDIR%"
goto success
:missing
echo ERROR: Project source files missing. Extract the ENTIRE ZIP, then run BUILD.cmd from its extracted folder.
goto fail
:missingassets
echo ERROR: Required assembler assets are missing. Extract the entire ZIP including assets.
goto fail
:nodotnet
echo ERROR: dotnet.exe not found. Install the .NET 10 SDK (not just runtime) and reopen the command window.
goto fail
:oldsdk
echo ERROR: .NET SDK 10.x is required by this project.
echo Install .NET 10 SDK for Windows x64, then retry.
goto fail
:restorefail
echo ERROR: NuGet restore failed. Full error:
type "%LOGDIR%\restore.log"
echo.
echo Send me build-logs\restore.log.
goto fail
:buildfail
echo ERROR: C# build failed. Full error:
type "%LOGDIR%\build.log"
echo.
echo Send me build-logs\build.log.
goto fail
:publishfail
echo ERROR: Publish failed. Full error:
type "%LOGDIR%\publish.log"
echo.
echo Send me build-logs\publish.log.
goto fail
:exe_missing
echo ERROR: Publish returned success but no W65C816Studio.exe was found.
goto fail
:examplesmissing
echo ERROR: Published EXE is missing example assets.
goto fail
:toolsmissing
echo ERROR: Published EXE is missing the ca65 toolchain.
goto fail
:fail
echo.
echo BUILD/PUBLISH FAILED. Look above for the specific error.
popd
pause
exit /b 1
:success
popd
pause
exit /b 0
