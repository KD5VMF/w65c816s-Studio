using System.Windows;
namespace W65C816.Studio;
public partial class App : Application { }
