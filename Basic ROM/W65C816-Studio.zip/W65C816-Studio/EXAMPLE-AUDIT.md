# W65C816 Studio - example audit

Every menu entry checked against the bundled file and its included dependencies. This is a structural/source audit, not a board execution test.

| Menu | ASM file | SHA256 (first 12) | Check |
|---|---|---|---|
| EDU · 8 LED chase | `EDU-LEDs.s` | `854631576a73` | Found |
| EDU · Buzzer beep | `EDU-Buzzer.s` | `4e57af6a4190` | Found |
| EDU · Banked RAM check | `EDU-RAM.s` | `781e4f9a57a9` | Found |
| EDU · I²C bus scan | `EDU-I2C-Scan.s` | `0000958cd051` | Found |
| EDU · SPI RAM check | `EDU-SPI-RAM.s` | `8a3e617a14a4` | Found |
| EDU · OLED text demo | `EDU-OLED-Text.s` | `d05cf3639d96` | Found |
| EDU · OLED 512K RAM test | `EDU-OLED-512K-RAM-Test.s` | `bb4670c52cd0` | Found |
| EDU · OLED RTC clock | `EDU-OLED-RTC-Clock.s` | `8c53b5ada162` | Found |
| SXB · X LED sweep | `LED-Sweep.s` | `3c2780d0c1a2` | Found |
| SXB · X LED sweep | `LED-Sweep.s` | `3c2780d0c1a2` | Found |

**PASS:** Original 9 examples retained; new temperature example added (10 total)., all include dependencies found, LED chase distinct from OLED demo.

Verified example files are refreshed from the packaged source, with backups for local modifications. Older root-level workspace files remain untouched.

**Not verified:** ca65/ld65 compilation on Windows and actual attached board behavior.

| EDU · Large Fahrenheit temperature | `EDU-OLED-Temperature-F.s` | Added | ADS1015 AIN2 / MCP9700A; 128x64 SSD1306, large °F |

| EDU · OLED primes to 1 million | `EDU-OLED-Primes-1Million.s` | faf0bb4eb93e | Bundled, menu mapped; ca65/board run not verified |
