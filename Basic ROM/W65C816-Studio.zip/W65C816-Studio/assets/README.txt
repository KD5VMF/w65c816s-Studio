W65C816 STUDIO — C# WINDOWS APPLICATION

Extract the entire ZIP into a writable folder and double-click W65C816Studio.exe.
Windows 10/11 x64. Self-contained: no VS Code, Python or .NET installation needed.
Keep the tools and examples folders beside the executable.

Select W65C816SXB + EDU, choose a USB COM port, open an example, press RESET on
this board, then click Build & Run (F5). F6 builds only. Upload only builds and
loads without executing. Read test results reads $3000-$31FF from a stopped board.

The application is written in C# / WPF. Your board programs use 65816 assembly
with ca65/ld65. C# does not run on the 65816. Source for the C# application is
included in Source. See EDU-GUIDE.html for EDU examples and limitations.

Examples: SXB X LEDs; EDU 8 LEDs, buzzer, parallel RAM, I2C scan, SPI RAM, OLED text, OLED full 512K RAM test, OLED RTC clock.
The EDU profile is manually selected. The 512 KB RAM map uses banks $08-$0F
per WDC's current getting-started guide. OLED and RTC drivers are included in the standalone OLED examples; ADC/crypto drivers
and hardware breakpoint/single-step debugging are not included.

Compiled and protocol-tested on Linux. The Windows interface and EDU peripheral
examples have not yet been run on Windows hardware. The original SXB LED sweep
was tested on the connected SXB.

Source build with .NET 10 SDK:
  dotnet publish Source/Studio/Studio.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
Tests:
  dotnet run --project Source/Tests/Studio.Tests.csproj -c Release
