; Writes and verifies a 256-byte pattern at EDU $08:0000-$08:00FF.
; Result at SXB $3000: $A5=pass, $FF=fail. LED FF=pass, 01=fail.
; This changes the first 256 bytes of expansion RAM.
.setcpu "65816"
.a8
.i8
.include "edu.inc"
.segment "CODE"
start:
    sei
    cld
    clc
    xce                      ; Native 65816 mode
    sep #$30                 ; 8-bit A, X, Y
    EDU_LED_INIT
    ldx #0
write_loop:
    txa
    sta f:EDU_RAM,x          ; Explicit 24-bit addressing
    inx
    bne write_loop
    ldx #0
read_loop:
    txa
    cmp f:EDU_RAM,x
    bne failed
    inx
    bne read_loop
    lda #$A5
    sta $3000
    lda #$FF
    bra finish
failed:
    lda #$FF
    sta $3000
    lda #1
finish:
    sta PIA_PA
    sec
    xce                      ; Return in emulation mode
    brk
    .byte 0
