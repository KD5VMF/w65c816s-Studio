; W65C816 EDU - REAL TIME CLOCK ON SSD1306 OLED
; SINGLE FILE ca65 ASM - open in W65C816 Studio and run at $2000.
;
; ====== CHANGE ONLY THESE THREE NUMBERS ======
START_HOUR   = 19       ; 0-23 (24 hour clock), e.g. 19 = 7 PM
START_MINUTE = 30       ; 0-59
START_SECOND = 0        ; 0-59
; ============================================
;
; Each time program starts it sets the EDU onboard MCP79411 RTC.
; RTC tracks seconds using its quartz crystal, NOT a CPU delay.
; OLED 128x64 SSD1306, address $3C, on EDU I2C bus.
; Display refreshes once per second; no 512K RAM is touched.
;
; W65C816SXB + EDU / SSD1306 128x64 I2C OLED
; ca65 source, direct-page pointer fixed. SSD1306 7-bit address $3C ($78 write).
; For 128x32 modules use settings noted below.
.setcpu "65816"
.a8
.i8
; W65C816SXB + W65C816EDU hardware definitions.
; See WDC EDU datasheet and getting-started correction for RAM banks.
PIA_PA      = $7FA0
PIA_CRA     = $7FA1
PIA_PB      = $7FA2
PIA_CRB     = $7FA3
VIA_ORB     = $7FC0
VIA_ORA     = $7FCF       ; Port A, no handshake
VIA_DDRB    = $7FC2
VIA_DDRA    = $7FC3
I2C_SCL     = $01         ; VIA PA0
I2C_SDA     = $80         ; VIA PA7
SPI_SCK     = $01         ; VIA PB0
SPI_MOSI    = $02         ; VIA PB1
SPI_RAM_CS  = $04         ; VIA PB2, active low
SPI_CLICK_CS= $08         ; VIA PB3, active low
SPI_MISO    = $20         ; VIA PB5
EDU_RAM     = $080000     ; Banks $08-$0F, NOT $01-$08
EDU_RAM_END = $0FFFFF
; PIA CA2 forced low/high, IRQs disabled, Port A data selected.
BUZZER_OFF  = $34
BUZZER_ON   = $3C

.macro EDU_LED_INIT
    lda #$30              ; CA2 low; select DDRA
    sta PIA_CRA
    lda #$FF
    sta PIA_PA            ; All Port A pins output
    lda #BUZZER_OFF       ; Select output data register; buzzer off
    sta PIA_CRA
    stz PIA_PA
.endmacro


OLED_WRITE  = $78            ; change to $7A for I2C address $3D
RTC_WRITE   = $DE            ; MCP79411 7-bit address $6F
RTC_READ    = $DF
RTC_SECONDS = ((START_SECOND / 10) * 16) + (START_SECOND - (START_SECOND / 10) * 10) + $80
RTC_MINUTES = ((START_MINUTE / 10) * 16) + (START_MINUTE - (START_MINUTE / 10) * 10)
RTC_HOURS   = ((START_HOUR / 10) * 16) + (START_HOUR - (START_HOUR / 10) * 10)
.assert START_HOUR >= 0 .and START_HOUR <= 23, error, "START_HOUR must be 0..23"
.assert START_MINUTE >= 0 .and START_MINUTE <= 59, error, "START_MINUTE must be 0..59"
.assert START_SECOND >= 0 .and START_SECOND <= 59, error, "START_SECOND must be 0..59"
TEXT_PTR    = $00E0
TEXT_INDEX  = $00E2
PAGE_NO     = $00E3
FONT_OFFSET = $00E4
GLYPH_COUNT = $00E5
CHAR_VALUE  = $00E6
I2C_ACK     = $00E8
RTC_LASTSEC = $00E9
RTC_SEC     = $00EA
RTC_MIN     = $00EB
RTC_HR      = $00EC
TIME_LINE   = $0300         ; eight chars + NUL at $0300

.segment "CODE"
start:
    sei
    sec
    xce                     ; emulation mode
    cld
    jsr i2c_init

    ; SSD1306 initialization, commands from table
    ldx #$00
@init:
    lda init_cmds,x
    cmp #$FF
    beq @init_done
    phx
    jsr oled_cmd
    plx
    inx
    bra @init
@init_done:
    ; Clear all 8 pages (for 128x32 OLED change #8 to #4)
    stz PAGE_NO
@clear_page:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    ldx #$80                ; 128 columns
@clear_col:
    lda #0
    jsr i2c_write
    dex
    bne @clear_col
    jsr i2c_stop
    inc PAGE_NO
    lda PAGE_NO
    cmp #8                  ; use 4 for 128x32
    bne @clear_page

    ; Start the clock at the user-supplied time every run.
    jsr rtc_set_time

    ; Permanent heading at OLED page 0.
    lda #0
    sta PAGE_NO
    lda #<title_line
    sta TEXT_PTR
    lda #>title_line
    sta TEXT_PTR+1
    jsr print_line

    ; Permanent bottom heading at page 6.
    lda #6
    sta PAGE_NO
    lda #<bottom_line
    sta TEXT_PTR
    lda #>bottom_line
    sta TEXT_PTR+1
    jsr print_line

    ; Create RAM buffer 00:00:00; update every second.
    ldx #0
@copy_time:
    lda time_template,x
    sta TIME_LINE,x
    inx
    cpx #9
    bne @copy_time
    lda #$FF
    sta RTC_LASTSEC

main_loop:
    jsr rtc_get_time
    lda RTC_SEC
    cmp RTC_LASTSEC
    beq main_loop
    sta RTC_LASTSEC

    ; RTC values are BCD: display tens and ones as ASCII.
    lda RTC_HR
    ldx #0
    jsr bcd_to_text
    lda RTC_MIN
    ldx #3
    jsr bcd_to_text
    lda RTC_SEC
    ldx #6
    jsr bcd_to_text

    lda #3                 ; Time centered vertically on page 3
    sta PAGE_NO
    lda #<TIME_LINE
    sta TEXT_PTR
    lda #>TIME_LINE
    sta TEXT_PTR+1
    jsr print_line
    jmp main_loop

; Input A=packed BCD, X=offset into TIME_LINE.
; Preserve original byte to read low nibble.
bcd_to_text:
    pha
    lsr a
    lsr a
    lsr a
    lsr a
    ora #$30
    sta TIME_LINE,x
    inx
    pla
    and #$0F
    ora #$30
    sta TIME_LINE,x
    rts

; Set MCU's RTC registers 00..02 in one I2C transfer.
; RTC seconds bit 7=1 starts its oscillator.
rtc_set_time:
    jsr i2c_start
    lda #RTC_WRITE
    jsr i2c_write
    lda #$00              ; start at register 00 (seconds)
    jsr i2c_write
    lda #RTC_SECONDS
    jsr i2c_write
    lda #RTC_MINUTES
    jsr i2c_write
    lda #RTC_HOURS        ; 24-hour mode (bit 6 clear)
    jsr i2c_write
    jmp i2c_stop

; Read current seconds/minutes/hours. Bit 7 stripped from seconds.
rtc_get_time:
    jsr i2c_start
    lda #RTC_WRITE
    jsr i2c_write
    lda #$00              ; register pointer -> seconds
    jsr i2c_write
    jsr i2c_restart       ; repeated START, no STOP
    lda #RTC_READ
    jsr i2c_write
    lda #0                ; ACK read, more bytes to follow
    jsr i2c_read
    and #$7F              ; remove oscillator ST bit
    sta RTC_SEC
    lda #0
    jsr i2c_read
    and #$7F
    sta RTC_MIN
    lda #1                ; last byte -> NACK
    jsr i2c_read
    and #$3F              ; 24-hour-mode hour bits
    sta RTC_HR
    jmp i2c_stop

; Repeated START while SCL held low: release SDA, raise SCL,
; pull SDA low, then SCL low. Does not change port latches.
i2c_restart:
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SDA
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay

; Reads 8 bits, MSB first. A=0 sends ACK; A=1 sends NACK.
; Uses port-direction switching for open-drain.
i2c_read:
    sta I2C_ACK
    stz I2C_BYTE
    lda VIA_DDRA
    and #$7F              ; release SDA
    ora #I2C_SCL         ; hold SCL low
    sta VIA_DDRA
    ldy #8
@read_bit:
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE              ; release SCL high
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #I2C_SDA
    beq @zero
    sec
    bra @store
@zero:
    clc
@store:
    rol I2C_BYTE
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    dey
    bne @read_bit
    lda VIA_DDRA
    ldx I2C_ACK
    bne @nack
    ora #I2C_SDA         ; drive SDA low = ACK
    bra @drive
@nack:
    and #$7F              ; leave SDA high = NACK
@drive:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE              ; SCL high
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SCL         ; SCL low
    and #$7F              ; release SDA after response
    sta VIA_DDRA
    jsr i2c_delay
    lda I2C_BYTE
    rts

; A = command byte. Each command sent in its own transaction.
oled_cmd:
    pha
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$00                ; command control byte
    jsr i2c_write
    pla
    jsr i2c_write
    jmp i2c_stop

; A = page 0 through 7, set column 0
oled_position:
    ora #$B0
    jsr oled_cmd
    lda #$00
    jsr oled_cmd
    lda #$10
    jmp oled_cmd

oled_data_begin:
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$40                ; data control byte
    jmp i2c_write

; TEXT_PTR points to zero-terminated text, max 21 characters.
; Glyphs are 5 columns plus 1 blank.
print_line:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    stz TEXT_INDEX
@next_char:
    ldy TEXT_INDEX
    lda (TEXT_PTR),y
    beq @end
    sta CHAR_VALUE
    ; Look up glyph in table, default to blank.
    ldx #0
@find:
    lda font_chars,x
    beq @space
    cmp CHAR_VALUE
    beq @found
    inx
    bra @find
@space:
    ldx #0
@found:
    ; X = character index; multiply by 5.
    txa
    sta FONT_OFFSET
    asl a
    asl a
    clc
    adc FONT_OFFSET
    tax
    lda #5
    sta GLYPH_COUNT
@draw:
    lda font_data,x
    phx
    jsr i2c_write
    plx
    inx
    dec GLYPH_COUNT
    bne @draw
    lda #0
    jsr i2c_write
    inc TEXT_INDEX
    lda TEXT_INDEX
    cmp #21
    bcc @next_char
@end:
    jmp i2c_stop

; Init for 128x64 SSD1306.
; For 128x32: change $A8,$3F to $A8,$1F
; and $DA,$12 to $DA,$02, and use only pages 0..3.
init_cmds:
    .byte $AE,$D5,$80,$A8,$3F,$D3,$00,$40,$8D,$14
    .byte $20,$02,$A1,$C8,$DA,$12,$81,$CF,$D9,$F1
    .byte $DB,$40,$A4,$A6,$2E,$AF,$FF

title_line:  .asciiz "W65C816 EDU"
bottom_line: .asciiz "RTC CLOCK"
time_template: .asciiz "00:00:00"

; Font order in font_chars. 5x7 column-major, bit 0 = top.
font_chars: .byte " ABCDEFGHIKLMNORUW2568Y!10S3479:T",0
font_data:
    ; space
    .byte $00,$00,$00,$00,$00
    ; A B C D E F G H I K L M N O R U W 2 5 6 8 Y !
    .byte $7E,$11,$11,$11,$7E ; A
    .byte $7F,$49,$49,$49,$36 ; B
    .byte $3E,$41,$41,$41,$22 ; C
    .byte $7F,$41,$41,$22,$1C ; D
    .byte $7F,$49,$49,$49,$41 ; E
    .byte $7F,$09,$09,$09,$01 ; F
    .byte $3E,$41,$49,$49,$7A ; G
    .byte $7F,$08,$08,$08,$7F ; H
    .byte $00,$41,$7F,$41,$00 ; I
    .byte $7F,$08,$14,$22,$41 ; K
    .byte $7F,$40,$40,$40,$40 ; L
    .byte $7F,$02,$0C,$02,$7F ; M
    .byte $7F,$04,$08,$10,$7F ; N
    .byte $3E,$41,$41,$41,$3E ; O
    .byte $7F,$09,$19,$29,$46 ; R
    .byte $3F,$40,$40,$40,$3F ; U
    .byte $3F,$40,$38,$40,$3F ; W
    .byte $62,$51,$49,$49,$46 ; 2
    .byte $27,$45,$45,$45,$39 ; 5
    .byte $3C,$4A,$49,$49,$30 ; 6
    .byte $36,$49,$49,$49,$36 ; 8
    .byte $07,$08,$70,$08,$07 ; Y
    .byte $00,$00,$5F,$00,$00 ; !
    .byte $00,$42,$7F,$40,$00 ; 1
    .byte $3E,$51,$49,$45,$3E ; 0
    .byte $46,$49,$49,$49,$31 ; S
    .byte $22,$41,$49,$49,$36 ; 3
    .byte $18,$14,$12,$7F,$10 ; 4
    .byte $01,$71,$09,$05,$03 ; 7
    .byte $06,$49,$49,$29,$1E ; 9
    .byte $00,$36,$36,$00,$00 ; :
    .byte $01,$01,$7F,$01,$01 ; T

; Single-master bit-banged I2C for EDU VIA PA0 / PA7.
; Direction switching implements open-drain, with the EDU pull-ups.
; Does not support clock stretching or multi-master arbitration.
; Clobbers A,Y and scratch $00E7. Preserves X.
I2C_BYTE = $00E7

i2c_delay:
    phx
    ldx #20
@wait:
    dex
    bne @wait
    plx
    rts

i2c_init:
    lda VIA_ORA
    and #$7E
    sta VIA_ORA             ; Output latch remains low on SDA and SCL
    lda VIA_DDRA
    and #$7E
    sta VIA_DDRA            ; Both lines released
    jmp i2c_delay

i2c_start:
    jsr i2c_init
    lda VIA_DDRA
    ora #I2C_SDA
    sta VIA_DDRA            ; SDA low while SCL high
    jsr i2c_delay
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay

i2c_stop:
    lda VIA_DDRA
    ora #$81
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE
    sta VIA_DDRA            ; SCL high
    jsr i2c_delay
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; SDA high
    jmp i2c_delay

; Input A=byte. Output carry clear=ACK, set=NACK.
i2c_write:
    sta I2C_BYTE
    ldy #8
@bit:
    asl I2C_BYTE
    lda VIA_DDRA
    bcs @one
    ora #$80
    bra @data
@one:
    and #$7F
@data:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    dey
    bne @bit
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; Release SDA for slave ACK
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #$80
    pha
    lda VIA_DDRA
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    pla
    beq @ack
    sec
    rts
@ack:
    clc
    rts

