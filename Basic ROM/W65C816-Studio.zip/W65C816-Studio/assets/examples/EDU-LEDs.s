; EDU 8-LED chase, active high. Buzzer is held off.
.setcpu "65816"
.a8
.i8
.include "edu.inc"
.segment "CODE"
start:
    sei
    sec
    xce
    cld
    EDU_LED_INIT
    lda #1
next:
    sta PIA_PA
    pha
    jsr delay
    pla
    asl a
    bne next
    lda #1
    bra next

delay:
    ldy #0
outer:
    ldx #0
inner:
    nop
    nop
    dex
    bne inner
    dey
    bne outer
    rts
