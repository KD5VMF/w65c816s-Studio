; Scan 7-bit I2C addresses $08-$77, then BRK to monitor.
; $3000 = count, $3100 onward = responding addresses (7-bit).
; Existing device registers are not written. Sends write address then STOP.
; PIA LEDs display count. Requires EDU, no clock-stretching devices.
.setcpu "65816"
.a8
.i8
.include "edu.inc"
.segment "CODE"
start:
    sei
    sec
    xce
    cld
    EDU_LED_INIT
    stz $3000
    lda #8
    sta $3001
    ldx #0
@scan:
    jsr i2c_start
    lda $3001
    asl a
    jsr i2c_write
    bcs @missing
    lda $3001
    sta $3100,x
    inx
    inc $3000
@missing:
    jsr i2c_stop
    inc $3001
    lda $3001
    cmp #$78
    bne @scan
    lda $3000
    sta PIA_PA
    brk
    .byte 0
.include "i2c.inc"
