; W65C816 EDU + SSD1306 OLED - PRIMES FROM 2 THROUGH 1,000,000
; W65C816 Studio / ca65 single file. Load at $2000.
; Displays every prime in sequence, a running prime total, and pass number.
; Automatically starts again at 2 after checking 1,000,000.
; True 24-bit numbers (no 65,535 rollover).
; Uses trial division up to sqrt(N), with 24-bit binary remainder.
; Uses SSD1306 OLED at I2C 7-bit address $3C (128x64), via EDU VIA PA0/PA7.
; No sensor or ADC required. Prime count at the end of each pass: 78,498.
; WARNING: sending every prime to the OLED via bit-banged I2C is slow.
;          For faster calculations, raise DISPLAY_EVERY from 1 to e.g. 16.
;
; DISPLAY_EVERY: 1 shows ALL primes; 2, 4, 8, 16... show periodic primes.
DISPLAY_EVERY = 1

.setcpu "65816"
.a8
.i8
VIA_ORA   = $7FCF
VIA_DDRA  = $7FC3
I2C_SCL   = $01
I2C_SDA   = $80
OLED_WRITE= $78
TEXT_PTR  = $00E0
TEXT_INDEX= $00E2
PAGE_NO   = $00E3
FONT_OFFSET=$00E4
GLYPH_COUNT=$00E5
CHAR_VALUE=$00E6
I2C_BYTE  = $00E7

; Work area in bank-zero direct page (do not overlap OLED scratch).
N         = $00A0      ; 24-bit candidate
PCOUNT    = $00A3      ; 24-bit number of primes in current pass
PASSNO    = $00A6      ; 24-bit completed + current pass number
DIVISOR   = $00A9      ; 16-bit odd trial divisor
SQUARE    = $00AB      ; 24-bit divisor squared
DELTA     = $00AE      ; 16-bit increment to square (4*d+4)
SHIFTNUM  = $00B0      ; 24-bit temporary dividend, shifted left
REM16     = $00B3      ; 16-bit remainder
LOOPS     = $00B5      ; bit counter
NUMBER    = $00B6      ; 24-bit decimal formatter input
DIGITVAL  = $00B9      ; current decimal digit ASCII
DIGITIDX  = $00BA      ; decimal digit index
OUTPTR    = $00BB      ; 16-bit pointer to seven-character destination
DRAWCTR   = $00BD      ; counts primes since last OLED update
LAST      = $00BE      ; last accepted prime (24-bit)

.segment "CODE"
start:
    sei
    sec
    xce                    ; emulation mode, same as known OLED example
    cld
    jsr i2c_init
    ldx #0
@oled_init:
    lda init_cmds,x
    cmp #$FF
    beq @init_done
    phx
    jsr oled_cmd
    plx
    inx
    bra @oled_init
@init_done:
    jsr clear_oled
    lda #0
    sta PAGE_NO
    lda #<heading
    sta TEXT_PTR
    lda #>heading
    sta TEXT_PTR+1
    jsr print_line
    stz PASSNO
    stz PASSNO+1
    stz PASSNO+2

restart_pass:
    ; Count the first pass as #1.
    inc PASSNO
    bne @pass_ok
    inc PASSNO+1
    bne @pass_ok
    inc PASSNO+2
@pass_ok:
    stz PCOUNT
    stz PCOUNT+1
    stz PCOUNT+2
    stz DRAWCTR
    jsr display_count
    jsr display_pass
    lda #2
    sta N
    stz N+1
    stz N+2
    jsr accept_prime        ; 2 is prime
    lda #3
    sta N

next_odd:
    ; If N > $0F4240 (1,000,000), pass completed.
    lda N+2
    cmp #$0F
    bcc @in_range
    bne pass_done
    lda N+1
    cmp #$42
    bcc @in_range
    bne pass_done
    lda N
    cmp #$40
    bcc @in_range
    beq @in_range
    jmp pass_done
@in_range:
    jsr check_prime
    bcc @not_prime
    jsr accept_prime
@not_prime:
    clc
    lda N
    adc #2
    sta N
    lda N+1
    adc #0
    sta N+1
    lda N+2
    adc #0
    sta N+2
    jmp next_odd

pass_done:
    ; Force final display (last prime 999983, count 78498).
    jsr display_prime
    jsr display_count
    jsr display_pass
    jmp restart_pass

; Returns C=1 if current N is prime, C=0 if composite.
; N is odd and >= 3. Test odd divisors until d*d > N.
check_prime:
    lda #3
    sta DIVISOR
    stz DIVISOR+1
    lda #9
    sta SQUARE
    stz SQUARE+1
    stz SQUARE+2
@try_divisor:
    ; If SQUARE > N, N must be prime.
    lda SQUARE+2
    cmp N+2
    bcc @divide
    bne @is_prime
    lda SQUARE+1
    cmp N+1
    bcc @divide
    bne @is_prime
    lda SQUARE
    cmp N
    bcc @divide
    beq @divide
@is_prime:
    sec
    rts
@divide:
    jsr divisible
    bcc @composite

    ; d = d+2; square = square + (4*old_d + 4)
    ; delta < 4008 for all relevant d <= 999.
    lda DIVISOR
    sta DELTA
    lda DIVISOR+1
    sta DELTA+1
    asl DELTA
    rol DELTA+1
    asl DELTA
    rol DELTA+1
    clc
    lda DELTA
    adc #4
    sta DELTA
    lda DELTA+1
    adc #0
    sta DELTA+1
    clc
    lda SQUARE
    adc DELTA
    sta SQUARE
    lda SQUARE+1
    adc DELTA+1
    sta SQUARE+1
    lda SQUARE+2
    adc #0
    sta SQUARE+2
    clc
    lda DIVISOR
    adc #2
    sta DIVISOR
    lda DIVISOR+1
    adc #0
    sta DIVISOR+1
    jmp @try_divisor
@composite:
    clc
    rts

; Binary long division, 24-bit N by 16-bit DIVISOR.
; Return C=0 when exactly divisible, C=1 otherwise.
; 24 cycles with remainder never exceeding 2*DIVISOR.
divisible:
    lda N
    sta SHIFTNUM
    lda N+1
    sta SHIFTNUM+1
    lda N+2
    sta SHIFTNUM+2
    stz REM16
    stz REM16+1
    lda #24
    sta LOOPS
@next_bit:
    asl SHIFTNUM
    rol SHIFTNUM+1
    rol SHIFTNUM+2
    rol REM16
    rol REM16+1
    lda REM16+1
    cmp DIVISOR+1
    bcc @skip_sub
    bne @subtract
    lda REM16
    cmp DIVISOR
    bcc @skip_sub
@subtract:
    sec
    lda REM16
    sbc DIVISOR
    sta REM16
    lda REM16+1
    sbc DIVISOR+1
    sta REM16+1
@skip_sub:
    dec LOOPS
    bne @next_bit
    lda REM16
    ora REM16+1
    beq @composite
    sec
    rts
@composite:
    clc
    rts

accept_prime:
    lda N
    sta LAST
    lda N+1
    sta LAST+1
    lda N+2
    sta LAST+2
    inc PCOUNT
    bne @count_ok
    inc PCOUNT+1
    bne @count_ok
    inc PCOUNT+2
@count_ok:
    inc DRAWCTR
    lda DRAWCTR
    cmp #DISPLAY_EVERY
    bcc @skip_prime
    stz DRAWCTR
    jsr display_prime
@skip_prime:
    ; Refresh count and pass every 64 discovered primes.
    lda PCOUNT
    and #$3F
    bne @done
    jsr display_count
    jsr display_pass
@done:
    rts

display_prime:
    lda LAST
    sta NUMBER
    lda LAST+1
    sta NUMBER+1
    lda LAST+2
    sta NUMBER+2
    lda #<(prime_line+6)
    sta OUTPTR
    lda #>(prime_line+6)
    sta OUTPTR+1
    jsr decimal7
    lda #2
    sta PAGE_NO
    lda #<prime_line
    sta TEXT_PTR
    lda #>prime_line
    sta TEXT_PTR+1
    jmp print_line

display_count:
    lda PCOUNT
    sta NUMBER
    lda PCOUNT+1
    sta NUMBER+1
    lda PCOUNT+2
    sta NUMBER+2
    lda #<(count_line+6)
    sta OUTPTR
    lda #>(count_line+6)
    sta OUTPTR+1
    jsr decimal7
    lda #4
    sta PAGE_NO
    lda #<count_line
    sta TEXT_PTR
    lda #>count_line
    sta TEXT_PTR+1
    jmp print_line

display_pass:
    lda PASSNO
    sta NUMBER
    lda PASSNO+1
    sta NUMBER+1
    lda PASSNO+2
    sta NUMBER+2
    lda #<(pass_line+6)
    sta OUTPTR
    lda #>(pass_line+6)
    sta OUTPTR+1
    jsr decimal7
    lda #6
    sta PAGE_NO
    lda #<pass_line
    sta TEXT_PTR
    lda #>pass_line
    sta TEXT_PTR+1
    jmp print_line

; Convert 24-bit NUMBER (0..16,777,215) to 7 ASCII digits,
; using place subtraction (no 32-bit arithmetic needed).
; For the requested limit and realistic pass count, max 7 digits.
decimal7:
    stz DIGITIDX
@next_digit:
    lda #$30                 ; ASCII zero; ca65-safe syntax
    sta DIGITVAL
@sub_loop:
    ldx DIGITIDX
    lda place0,x
    sta DELTA           ; use DELTA as lowest two place bytes
    lda place1,x
    sta DELTA+1
    ; compare NUMBER >= three-byte place value
    lda NUMBER+2
    cmp place2,x
    bcc @write_digit
    bne @subtract
    lda NUMBER+1
    cmp DELTA+1
    bcc @write_digit
    bne @subtract
    lda NUMBER
    cmp DELTA
    bcc @write_digit
@subtract:
    sec
    lda NUMBER
    sbc DELTA
    sta NUMBER
    lda NUMBER+1
    sbc DELTA+1
    sta NUMBER+1
    lda NUMBER+2
    sbc place2,x
    sta NUMBER+2
    inc DIGITVAL
    bra @sub_loop
@write_digit:
    ldy DIGITIDX
    lda DIGITVAL
    sta (OUTPTR),y
    inc DIGITIDX
    lda DIGITIDX
    cmp #7
    bne @next_digit
    rts

; 1,000,000; 100,000; 10,000; 1,000; 100; 10; 1
place0: .byte $40,$A0,$10,$E8,$64,$0A,$01
place1: .byte $42,$86,$27,$03,$00,$00,$00
place2: .byte $0F,$01,$00,$00,$00,$00,$00

clear_oled:
    stz PAGE_NO
@next_page:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    ldx #128
@blank:
    lda #0
    jsr i2c_write
    dex
    bne @blank
    jsr i2c_stop
    inc PAGE_NO
    lda PAGE_NO
    cmp #8
    bne @next_page
    rts

oled_cmd:
    pha
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$00                ; command control byte
    jsr i2c_write
    pla
    jsr i2c_write
    jmp i2c_stop

; A = page 0 through 7, set column 0
oled_position:
    ora #$B0
    jsr oled_cmd
    lda #$00
    jsr oled_cmd
    lda #$10
    jmp oled_cmd

oled_data_begin:
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$40                ; data control byte
    jmp i2c_write

; TEXT_PTR points to zero-terminated text, max 21 characters.
; Glyphs are 5 columns plus 1 blank.
print_line:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    stz TEXT_INDEX
@next_char:
    ldy TEXT_INDEX
    lda (TEXT_PTR),y
    beq @end
    sta CHAR_VALUE
    ; Look up glyph in table, default to blank.
    ldx #0
@find:
    lda font_chars,x
    beq @space
    cmp CHAR_VALUE
    beq @found
    inx
    bra @find
@space:
    ldx #0
@found:
    ; X = character index; multiply by 5.
    txa
    sta FONT_OFFSET
    asl a
    asl a
    clc
    adc FONT_OFFSET
    tax
    lda #5
    sta GLYPH_COUNT
@draw:
    lda font_data,x
    phx
    jsr i2c_write
    plx
    inx
    dec GLYPH_COUNT
    bne @draw
    lda #0
    jsr i2c_write
    inc TEXT_INDEX
    lda TEXT_INDEX
    cmp #21
    bcc @next_char
@end:
    jmp i2c_stop

; SSD1306 configuration, 128x64 display
init_cmds:
    .byte $AE,$D5,$80,$A8,$3F,$D3,$00,$40,$8D,$14
    .byte $20,$02,$A1,$C8,$DA,$12,$81,$CF,$D9,$F1
    .byte $DB,$40,$A4,$A6,$2E,$AF,$FF
heading:    .asciiz "PRIMES TO 1000000"
prime_line: .asciiz "PRIME 0000000"
count_line: .asciiz "COUNT 0000000"
pass_line:  .asciiz "PASS  0000000"
font_chars: .byte " ABCDEFGHIKLMNORUW2568Y!10S3479:TP",0
font_data:
    ; space
    .byte $00,$00,$00,$00,$00
    ; A B C D E F G H I K L M N O R U W 2 5 6 8 Y !
    .byte $7E,$11,$11,$11,$7E ; A
    .byte $7F,$49,$49,$49,$36 ; B
    .byte $3E,$41,$41,$41,$22 ; C
    .byte $7F,$41,$41,$22,$1C ; D
    .byte $7F,$49,$49,$49,$41 ; E
    .byte $7F,$09,$09,$09,$01 ; F
    .byte $3E,$41,$49,$49,$7A ; G
    .byte $7F,$08,$08,$08,$7F ; H
    .byte $00,$41,$7F,$41,$00 ; I
    .byte $7F,$08,$14,$22,$41 ; K
    .byte $7F,$40,$40,$40,$40 ; L
    .byte $7F,$02,$0C,$02,$7F ; M
    .byte $7F,$04,$08,$10,$7F ; N
    .byte $3E,$41,$41,$41,$3E ; O
    .byte $7F,$09,$19,$29,$46 ; R
    .byte $3F,$40,$40,$40,$3F ; U
    .byte $3F,$40,$38,$40,$3F ; W
    .byte $62,$51,$49,$49,$46 ; 2
    .byte $27,$45,$45,$45,$39 ; 5
    .byte $3C,$4A,$49,$49,$30 ; 6
    .byte $36,$49,$49,$49,$36 ; 8
    .byte $07,$08,$70,$08,$07 ; Y
    .byte $00,$00,$5F,$00,$00 ; !
    .byte $00,$42,$7F,$40,$00 ; 1
    .byte $3E,$51,$49,$45,$3E ; 0
    .byte $46,$49,$49,$49,$31 ; S
    .byte $22,$41,$49,$49,$36 ; 3
    .byte $18,$14,$12,$7F,$10 ; 4
    .byte $01,$71,$09,$05,$03 ; 7
    .byte $06,$49,$49,$29,$1E ; 9
    .byte $00,$36,$36,$00,$00 ; :
    .byte $01,$01,$7F,$01,$01 ; T

    .byte $7F,$09,$09,$09,$06 ; P

i2c_delay:
    phx
    ldx #20
@wait:
    dex
    bne @wait
    plx
    rts

i2c_init:
    lda VIA_ORA
    and #$7E
    sta VIA_ORA             ; Output latch remains low on SDA and SCL
    lda VIA_DDRA
    and #$7E
    sta VIA_DDRA            ; Both lines released
    jmp i2c_delay

i2c_start:
    jsr i2c_init
    lda VIA_DDRA
    ora #I2C_SDA
    sta VIA_DDRA            ; SDA low while SCL high
    jsr i2c_delay
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay

i2c_stop:
    lda VIA_DDRA
    ora #$81
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE
    sta VIA_DDRA            ; SCL high
    jsr i2c_delay
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; SDA high
    jmp i2c_delay

; Input A=byte. Output carry clear=ACK, set=NACK.
i2c_write:
    sta I2C_BYTE
    ldy #8
@bit:
    asl I2C_BYTE
    lda VIA_DDRA
    bcs @one
    ora #$80
    bra @data
@one:
    and #$7F
@data:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    dey
    bne @bit
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; Release SDA for slave ACK
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #$80
    pha
    lda VIA_DDRA
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    pla
    beq @ack
    sec
    rts
@ack:
    clc
    rts

