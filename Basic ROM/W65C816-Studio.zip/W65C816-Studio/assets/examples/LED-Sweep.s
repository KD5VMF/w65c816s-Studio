; W65C816SXB — bouncing X LED sweep
; Change HOLD to adjust speed. Each unit is about 74 ms at 8 MHz.
.setcpu "65816"
.a8
.i8
.export _start
HOLD = 4

.segment "CODE"
_start:
    sei
    sec
    xce                     ; Enter 8-bit emulation mode
    cld

.macro LIGHT address
    lda #HOLD
outer:
    ldy #0
middle:
    ldx #0
inner:
    bit address             ; Reading this address lights the X LED
    dex
    bne inner
    dey
    bne middle
    dec a
    bne outer
.endmacro

sweep:
    .scope
        LIGHT $7F00         ; X0
    .endscope
    .scope
        LIGHT $7F20         ; X1
    .endscope
    .scope
        LIGHT $7F40         ; X2
    .endscope
    .scope
        LIGHT $7F60         ; X3
    .endscope
    .scope
        LIGHT $7F40         ; X2
    .endscope
    .scope
        LIGHT $7F20         ; X1
    .endscope
    jmp sweep
