; Write $5A to serial SRAM byte 0, then read it back.
; Changes one byte of the EDU's 23LCV1024 SPI RAM.
; $3000=$A5 pass / $FF fail. $3001=read-back data.
.setcpu "65816"
.a8
.i8
.include "edu.inc"
.segment "CODE"
start:
    sei
    sec
    xce
    cld
    EDU_LED_INIT
    jsr spi_init
    jsr spi_select_ram
    lda #$02                 ; WRITE
    jsr spi_byte
    lda #0                   ; 24-bit address 000000
    jsr spi_byte
    lda #0
    jsr spi_byte
    lda #0
    jsr spi_byte
    lda #$5A
    jsr spi_byte
    jsr spi_release_ram
    jsr spi_select_ram
    lda #$03                 ; READ
    jsr spi_byte
    lda #0
    jsr spi_byte
    lda #0
    jsr spi_byte
    lda #0
    jsr spi_byte
    lda #0                   ; Dummy byte clocks response
    jsr spi_byte
    sta $3001
    jsr spi_release_ram
    lda $3001
    cmp #$5A
    bne failed
    lda #$A5
    sta $3000
    lda #$FF
    bra finish
failed:
    lda #$FF
    sta $3000
    lda #1
finish:
    sta PIA_PA
    brk
    .byte 0
.include "spi.inc"
