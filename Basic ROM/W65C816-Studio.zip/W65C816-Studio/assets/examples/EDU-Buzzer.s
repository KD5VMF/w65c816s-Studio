; One brief beep and return to the monitor.
; Turn ON the EDU's physical buzzer switch first.
.setcpu "65816"
.a8
.i8
.include "edu.inc"
.segment "CODE"
start:
    sei
    sec
    xce
    cld
    EDU_LED_INIT
    lda #BUZZER_ON
    sta PIA_CRA
    ldy #0
outer:
    ldx #0
inner:
    dex
    bne inner
    dey
    bne outer
    lda #BUZZER_OFF
    sta PIA_CRA
    brk
    .byte 0
