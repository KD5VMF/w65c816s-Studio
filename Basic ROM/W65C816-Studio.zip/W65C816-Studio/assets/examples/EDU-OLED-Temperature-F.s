; W65C816EDU: MCP9700A + ADS1015 -> LARGE OLED FAHRENHEIT
; Single-file ca65 assembly for W65C816 Studio, load at $2000.
; Requires fitted MCP9700A and ADS1015, 128x64 SSD1306 I2C OLED.
; ADC ADDR tied to GND = $48; edit ADC_WRITE if yours differs.
; ADC AIN2, single-ended, PGA +/-2.048V: each ADC count = 1 mV.
; MCP9700A nominal: 500mV at 0C, 10mV per degree C.
; Uses integer Fahrenheit, no floating point. Refreshes continuously.
; Note: accuracy is limited by sensor offset, ADC and installation.
.setcpu "65816"
.a8
.i8
VIA_ORA  = $7FCF
VIA_DDRA = $7FC3
I2C_SCL = $01
I2C_SDA = $80
OLED_WRITE = $78
ADC_WRITE = $90   ; ADS1015 7-bit $48
ADC_READ  = $91
TEXT_PTR = $00E0
TEXT_INDEX = $00E2
PAGE_NO = $00E3
FONT_OFFSET = $00E4
GLYPH_COUNT = $00E5
CHAR_VALUE = $00E6
I2C_ACK = $00E8
ADC_OK = $00E9
ADC_WORD = $00EA       ; 16-bit ADC conversion left aligned
MV = $00EC             ; 16-bit millivolts
WORK = $00EE           ; signed intermediate
TEMP_F = $00F0         ; signed Fahrenheit result
NEG_FLAG = $00F2
REMAINDER = $00F4
DIGIT_H = $00F6
DIGIT_T = $00F7
DIGIT_O = $00F8
DRAW_PAGE = $00F9
DRAW_POS = $00FA
GLYPH_ID = $00FB
BYTE_INDEX = $00FC
GLYPH_OFFSET = $00FD ; 16-bit pointer offset into big_font
BIG_PTR = $00D0        ; 16-bit pointer
; RAM display buffer, each item is big-font glyph number
DISPLAY = $0340
; glyph 0 space, 1..10 digits 0..9, 11 degree, 12 F, 13 minus
.segment "CODE"
start:
    sei
    sec
    xce                ; emulation mode for compatible monitor startup
    cld
    jsr i2c_init
    ldx #0
@init:
    lda init_cmds,x
    cmp #$FF
    beq @init_done
    phx
    jsr oled_cmd
    plx
    inx
    bra @init
@init_done:
    jsr oled_clear
    lda #0
    sta PAGE_NO
    lda #<title_line
    sta TEXT_PTR
    lda #>title_line
    sta TEXT_PTR+1
    jsr print_line
loop:
    jsr read_adc
    lda ADC_OK
    bne @good
    jsr oled_clear
    lda #3
    sta PAGE_NO
    lda #<error_line
    sta TEXT_PTR
    lda #>error_line
    sta TEXT_PTR+1
    jsr print_line
    jsr slow_pause
    jmp loop
@good:
    jsr convert_f
    jsr format_digits
    jsr draw_big
    jsr slow_pause
    jmp loop

; Clear all SSD1306 8 pages.
oled_clear:
    stz PAGE_NO
@next:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    ldx #128
@col:
    lda #0
    jsr i2c_write
    dex
    bne @col
    jsr i2c_stop
    inc PAGE_NO
    lda PAGE_NO
    cmp #8
    bne @next
    rts

; Program ADS1015 config register 0x01 for one-shot channel AIN2.
; 0xE583 = start conversion, AIN2/GND, +/-2.048V, single shot,
; 1600SPS, traditional comparator disabled.
; Wait for conversion, select reg 0x00, read high then low byte.
read_adc:
    stz ADC_OK
    jsr i2c_start
    lda #ADC_WRITE
    jsr i2c_write
    bcc @write_ok
    jsr i2c_stop
    rts
@write_ok:
    lda #$01
    jsr i2c_write
    lda #$E5
    jsr i2c_write
    lda #$83
    jsr i2c_write
    jsr i2c_stop
    jsr adc_pause
    jsr i2c_start
    lda #ADC_WRITE
    jsr i2c_write
    bcc @pointer_ok
    jsr i2c_stop
    rts
@pointer_ok:
    lda #$00
    jsr i2c_write
    jsr i2c_restart
    lda #ADC_READ
    jsr i2c_write
    bcc @read_ok
    jsr i2c_stop
    rts
@read_ok:
    lda #0
    jsr i2c_read
    sta ADC_WORD+1
    lda #1
    jsr i2c_read
    sta ADC_WORD
    jsr i2c_stop
    lda #1
    sta ADC_OK
    rts

; Work in 16-bit accumulator native mode. Index registers remain 8-bit.
; 12-bit ADS1015 output left-justified in 16-bit conversion register.
; N counts x 1mV/count at PGA 2.048V. F = 32 + ((N-500)*9)/50.
convert_f:
    clc
    xce                   ; native mode, for 16-bit arithmetic
    rep #$20
    .a16
    lda ADC_WORD
    lsr a
    lsr a
    lsr a
    lsr a
    sta MV
    sec
    sbc #500
    sta WORK
    stz NEG_FLAG
    bpl @positive
    lda #1
    sta NEG_FLAG
    lda WORK
    eor #$FFFF
    inc a
    sta WORK
@positive:
    lda WORK
    asl a
    asl a
    asl a
    clc
    adc WORK              ; 9*abs(mV-500)
    sta WORK
    stz REMAINDER
@divide:
    lda WORK
    cmp #50
    bcc @div_done
    sec
    sbc #50
    sta WORK
    inc REMAINDER
    bra @divide
@div_done:
    lda NEG_FLAG
    beq @plus
    lda #32
    sec
    sbc REMAINDER
    bra @done
@plus:
    lda REMAINDER
    clc
    adc #32
@done:
    sta TEMP_F
    sep #$20
    .a8
    sec
    xce                   ; return to emulation mode
    rts

; Render -xx or xxx Fahrenheit; valid range for this display -99..999F.
; Display glyphs: hundreds, tens, ones, degree, F.
format_digits:
    lda #11
    sta DISPLAY+3
    lda #12
    sta DISPLAY+4
    lda TEMP_F+1
    bmi @negative
    lda TEMP_F
    sta DIGIT_O
    lda TEMP_F+1
    sta DIGIT_T          ; temporary high byte
    stz DISPLAY
    bra @digits
@negative:
    sec
    lda #0
    sbc TEMP_F
    sta DIGIT_O
    lda #0
    sbc TEMP_F+1
    sta DIGIT_T
    lda #13
    sta DISPLAY
@digits:
    ; 16 bit division by 100 using byte-wise subtraction.
    ; DIGIT_T:DIGIT_O holds magnitude.
    stz DIGIT_H
@hundred:
    lda DIGIT_T
    bne @sub100
    lda DIGIT_O
    cmp #100
    bcc @tens_start
@sub100:
    sec
    lda DIGIT_O
    sbc #100
    sta DIGIT_O
    lda DIGIT_T
    sbc #0
    sta DIGIT_T
    inc DIGIT_H
    bra @hundred
@tens_start:
    stz DIGIT_T
@tens:
    lda DIGIT_O
    cmp #10
    bcc @set
    sec
    sbc #10
    sta DIGIT_O
    inc DIGIT_T
    bra @tens
@set:
    lda DIGIT_H
    beq @no_hundreds
    inc a
    sta DISPLAY
@no_hundreds:
    lda DIGIT_T
    bne @show_tens
    lda DISPLAY
    beq @blank_tens
@show_tens:
    lda DIGIT_T
    inc a
    sta DISPLAY+1
    bra @ones
@blank_tens:
    stz DISPLAY+1
@ones:
    lda DIGIT_O
    inc a
    sta DISPLAY+2
    rts

; 5 glyphs x 16 columns. Each glyph is 16x32 pixels, four pages.
; Large font is pre-scaled 5x7 (3x horizontally, 4x vertically).
; Draw each page in one transaction. Layout starts at OLED col 24.
draw_big:
    lda #0
    sta DRAW_PAGE
@page_loop:
    lda DRAW_PAGE
    clc
    adc #2
    jsr oled_position
    lda #$08             ; start column 24
    jsr oled_cmd         ; low column nibble
    lda #$11
    jsr oled_cmd         ; high column nibble
    jsr oled_data_begin
    stz DRAW_POS
@char_loop:
    ldx DRAW_POS
    lda DISPLAY,x
    sta GLYPH_ID
    ; glyph index*64 plus draw_page*16, pointer big_font + offset
    ; low/high using 8-bit accumulator, avoids needing native mode.
    stz GLYPH_OFFSET
    stz GLYPH_OFFSET+1
    lda GLYPH_ID
    asl a
    asl a
    asl a
    asl a
    asl a
    asl a
    sta GLYPH_OFFSET
    lda GLYPH_ID
    lsr a
    lsr a
    sta GLYPH_OFFSET+1
    lda DRAW_PAGE
    asl a
    asl a
    asl a
    asl a
    clc
    adc GLYPH_OFFSET
    sta GLYPH_OFFSET
    bcc @no_carry
    inc GLYPH_OFFSET+1
@no_carry:
    clc
    lda #<big_font
    adc GLYPH_OFFSET
    sta BIG_PTR
    lda #>big_font
    adc GLYPH_OFFSET+1
    sta BIG_PTR+1
    ldy #0
@font_col:
    lda (BIG_PTR),y
    phy
    jsr i2c_write
    ply
    iny
    cpy #16
    bne @font_col
    inc DRAW_POS
    lda DRAW_POS
    cmp #5
    bne @char_loop
    jsr i2c_stop
    inc DRAW_PAGE
    lda DRAW_PAGE
    cmp #4
    beq @complete
    jmp @page_loop
@complete:
    rts

; Conversion pause at least ADS1015 single-shot conversion time.
adc_pause:
    ldx #30
@outer:
    ldy #255
@inner:
    dey
    bne @inner
    dex
    bne @outer
    rts
slow_pause:
    ldx #150
@outer:
    ldy #255
@inner:
    dey
    bne @inner
    dex
    bne @outer
    rts

oled_cmd:
    pha
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$00                ; command control byte
    jsr i2c_write
    pla
    jsr i2c_write
    jmp i2c_stop

; A = page 0 through 7, set column 0
oled_position:
    ora #$B0
    jsr oled_cmd
    lda #$00
    jsr oled_cmd
    lda #$10
    jmp oled_cmd

oled_data_begin:
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$40                ; data control byte
    jmp i2c_write

; TEXT_PTR points to zero-terminated text, max 21 characters.
; Glyphs are 5 columns plus 1 blank.
print_line:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    stz TEXT_INDEX
@next_char:
    ldy TEXT_INDEX
    lda (TEXT_PTR),y
    beq @end
    sta CHAR_VALUE
    ; Look up glyph in table, default to blank.
    ldx #0
@find:
    lda font_chars,x
    beq @space
    cmp CHAR_VALUE
    beq @found
    inx
    bra @find
@space:
    ldx #0
@found:
    ; X = character index; multiply by 5.
    txa
    sta FONT_OFFSET
    asl a
    asl a
    clc
    adc FONT_OFFSET
    tax
    lda #5
    sta GLYPH_COUNT
@draw:
    lda font_data,x
    phx
    jsr i2c_write
    plx
    inx
    dec GLYPH_COUNT
    bne @draw
    lda #0
    jsr i2c_write
    inc TEXT_INDEX
    lda TEXT_INDEX
    cmp #21
    bcc @next_char
@end:
    jmp i2c_stop

init_cmds:
    .byte $AE,$D5,$80,$A8,$3F,$D3,$00,$40,$8D,$14
    .byte $20,$02,$A1,$C8,$DA,$12,$81,$CF,$D9,$F1
    .byte $DB,$40,$A4,$A6,$2E,$AF,$FF

title_line: .asciiz "TEMP SENSOR"
error_line: .asciiz "ADC ERROR"
font_chars: .byte " ABCDEFGHIKLMNORUW2568Y!10S3479:TP",0
font_data:
    ; space
    .byte $00,$00,$00,$00,$00
    ; A B C D E F G H I K L M N O R U W 2 5 6 8 Y !
    .byte $7E,$11,$11,$11,$7E ; A
    .byte $7F,$49,$49,$49,$36 ; B
    .byte $3E,$41,$41,$41,$22 ; C
    .byte $7F,$41,$41,$22,$1C ; D
    .byte $7F,$49,$49,$49,$41 ; E
    .byte $7F,$09,$09,$09,$01 ; F
    .byte $3E,$41,$49,$49,$7A ; G
    .byte $7F,$08,$08,$08,$7F ; H
    .byte $00,$41,$7F,$41,$00 ; I
    .byte $7F,$08,$14,$22,$41 ; K
    .byte $7F,$40,$40,$40,$40 ; L
    .byte $7F,$02,$0C,$02,$7F ; M
    .byte $7F,$04,$08,$10,$7F ; N
    .byte $3E,$41,$41,$41,$3E ; O
    .byte $7F,$09,$19,$29,$46 ; R
    .byte $3F,$40,$40,$40,$3F ; U
    .byte $3F,$40,$38,$40,$3F ; W
    .byte $62,$51,$49,$49,$46 ; 2
    .byte $27,$45,$45,$45,$39 ; 5
    .byte $3C,$4A,$49,$49,$30 ; 6
    .byte $36,$49,$49,$49,$36 ; 8
    .byte $07,$08,$70,$08,$07 ; Y
    .byte $00,$00,$5F,$00,$00 ; !
    .byte $00,$42,$7F,$40,$00 ; 1
    .byte $3E,$51,$49,$45,$3E ; 0
    .byte $46,$49,$49,$49,$31 ; S
    .byte $22,$41,$49,$49,$36 ; 3
    .byte $18,$14,$12,$7F,$10 ; 4
    .byte $01,$71,$09,$05,$03 ; 7
    .byte $06,$49,$49,$29,$1E ; 9
    .byte $00,$36,$36,$00,$00 ; :
    .byte $01,$01,$7F,$01,$01 ; T

    .byte $7F,$09,$09,$09,$06 ; P
; Single-master bit-banged I2C for EDU VIA PA0 / PA7.
; Direction switching implements open-drain, with the EDU pull-ups.
; Does not support clock stretching or multi-master arbitration.
; Clobbers A,Y and scratch $00E7. Preserves X.
I2C_BYTE = $00E7

i2c_delay:
    phx
    ldx #20
@wait:
    dex
    bne @wait
    plx
    rts

i2c_init:
    lda VIA_ORA
    and #$7E
    sta VIA_ORA             ; Output latch remains low on SDA and SCL
    lda VIA_DDRA
    and #$7E
    sta VIA_DDRA            ; Both lines released
    jmp i2c_delay

i2c_start:
    jsr i2c_init
    lda VIA_DDRA
    ora #I2C_SDA
    sta VIA_DDRA            ; SDA low while SCL high
    jsr i2c_delay
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay

i2c_stop:
    lda VIA_DDRA
    ora #$81
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE
    sta VIA_DDRA            ; SCL high
    jsr i2c_delay
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; SDA high
    jmp i2c_delay

; Input A=byte. Output carry clear=ACK, set=NACK.
i2c_write:
    sta I2C_BYTE
    ldy #8
@bit:
    asl I2C_BYTE
    lda VIA_DDRA
    bcs @one
    ora #$80
    bra @data
@one:
    and #$7F
@data:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    dey
    bne @bit
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; Release SDA for slave ACK
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #$80
    pha
    lda VIA_DDRA
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    pla
    beq @ack
    sec
    rts
@ack:
    clc
    rts


big_font:
    ; glyph ' '
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    ; glyph '0'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00
    .byte $FF,$FF,$FF,$00,$00,$00,$F0,$F0,$F0,$0F,$0F,$0F,$FF,$FF,$FF,$00
    .byte $FF,$FF,$FF,$0F,$0F,$0F,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $00,$00,$00,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '1'
    .byte $00,$00,$00,$F0,$F0,$F0,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '2'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$F0,$F0,$F0,$0F,$0F,$0F,$00
    .byte $00,$00,$00,$F0,$F0,$F0,$0F,$0F,$0F,$00,$00,$00,$00,$00,$00,$00
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00
    ; glyph '3'
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00
    .byte $00,$00,$00,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$0F,$0F,$0F,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '4'
    .byte $00,$00,$00,$00,$00,$00,$F0,$F0,$F0,$FF,$FF,$FF,$00,$00,$00,$00
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$00,$00,$00,$FF,$FF,$FF,$00,$00,$00,$00
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$FF,$FF,$FF,$0F,$0F,$0F,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '5'
    .byte $FF,$FF,$FF,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00
    .byte $FF,$FF,$FF,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '6'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00
    .byte $FF,$FF,$FF,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$00,$00,$00,$00
    .byte $FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $00,$00,$00,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '7'
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$FF,$FF,$FF,$00
    .byte $00,$00,$00,$00,$00,$00,$F0,$F0,$F0,$0F,$0F,$0F,$00,$00,$00,$00
    .byte $00,$00,$00,$FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$0F,$0F,$0F,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    ; glyph '8'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00
    .byte $0F,$0F,$0F,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$0F,$0F,$0F,$00
    .byte $FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $00,$00,$00,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph '9'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00
    .byte $0F,$0F,$0F,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$FF,$FF,$FF,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FF,$FF,$FF,$00
    .byte $0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00,$00,$00,$00
    ; glyph 'o'
    .byte $F0,$F0,$F0,$0F,$0F,$0F,$0F,$0F,$0F,$F0,$F0,$F0,$00,$00,$00,$00
    .byte $0F,$0F,$0F,$F0,$F0,$F0,$F0,$F0,$F0,$0F,$0F,$0F,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    ; glyph 'F'
    .byte $FF,$FF,$FF,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$0F,$00
    .byte $FF,$FF,$FF,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$00,$00,$00,$00
    .byte $FF,$FF,$FF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $0F,$0F,$0F,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    ; glyph '-'
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$F0,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00

i2c_restart:
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SDA
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay


i2c_read:
    sta I2C_ACK
    stz I2C_BYTE
    lda VIA_DDRA
    and #$7F              ; release SDA
    ora #I2C_SCL         ; hold SCL low
    sta VIA_DDRA
    ldy #8
@read_bit:
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE              ; release SCL high
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #I2C_SDA
    beq @zero
    sec
    bra @store
@zero:
    clc
@store:
    rol I2C_BYTE
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    dey
    bne @read_bit
    lda VIA_DDRA
    ldx I2C_ACK
    bne @nack
    ora #I2C_SDA         ; drive SDA low = ACK
    bra @drive
@nack:
    and #$7F              ; leave SDA high = NACK
@drive:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE              ; SCL high
    sta VIA_DDRA
    jsr i2c_delay
    ora #I2C_SCL         ; SCL low
    and #$7F              ; release SDA after response
    sta VIA_DDRA
    jsr i2c_delay
    lda I2C_BYTE
    rts

