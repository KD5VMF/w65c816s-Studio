; W65C816 EDU 512KB DESTRUCTIVE SRAM TEST + SSD1306 OLED
; Standalone ca65 source for W65C816 Studio. Load/run at $2000.
; RAM on the EDU is BANKS $08-$0F ($080000-$0FFFFF).
; WARNING: THIS TEST OVERWRITES ALL 512KB OF EDU EXPANSION RAM.
; Does not modify bank $00 program, stack, or monitor RAM.
; Assumes your existing working 128x64 SSD1306 at I2C $3C.
; Six patterns: 00 FF AA 55 bank/page/offset XOR + inverse.
; Each pass WRITES ALL BANKS first, then CHECKS ALL BANKS.
; Error counter saturates at FFFF. Shows last bad address and data.
.setcpu "65816"
.a8
.i8

VIA_ORA  = $7FCF
VIA_DDRA = $7FC3
I2C_SCL  = $01
I2C_SDA  = $80
OLED_WRITE = $78

; Scratch in native direct page (also zero page in emulation mode)
TEXT_PTR = $00E0
TEXT_INDEX = $00E2
PAGE_NO = $00E3
FONT_OFFSET = $00E4
GLYPH_COUNT = $00E5
CHAR_VALUE = $00E6
I2C_BYTE = $00E7
RAM_PTR = $00E8          ; 24-bit long indirect pointer $E8/$E9/$EA
PASS_NO = $00EB
PHASE_NO = $00EC       ; 0=WRITE, 1=CHECK
EXPECTED = $00ED
ACTUAL = $00EE
ERR_LO = $00EF
ERR_HI = $00F0
BAD_BANK = $00F1
BAD_HI = $00F2
BAD_LO = $00F3
BAD_EXP = $00F4
BAD_ACT = $00F5
BAD_SEEN = $00F6
NIBBLE_TMP = $00F7

; Mutable text buffers in bank 0, outside loaded application.
LINE1 = $0300            ; "512K ERR:0000"
LINE2 = $0320            ; "PASS:1/6 WRITE"
LINE3 = $0340            ; "BANK:08 PAGE:00"
LINE4 = $0360            ; "BAD:--:---- --/--"

.segment "CODE"
start:
    sei
    sec
    xce                  ; 65816 emulation, 8-bit A/X/Y
    cld
    jsr i2c_init
    ldx #0
@oled_init:
    lda init_cmds,x
    cmp #$FF
    beq @oled_ready
    phx
    jsr oled_cmd
    plx
    inx
    bra @oled_init
@oled_ready:
    stz PAGE_NO
@clearpage:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    ldx #128
@clearcol:
    lda #0
    jsr i2c_write
    dex
    bne @clearcol
    jsr i2c_stop
    inc PAGE_NO
    lda PAGE_NO
    cmp #8
    bne @clearpage

    ; Copy templates from code into editable bank-0 RAM.
    ldx #0
@copy:
    lda template1,x
    sta LINE1,x
    lda template2,x
    sta LINE2,x
    lda template3,x
    sta LINE3,x
    lda template4,x
    sta LINE4,x
    inx
    cpx #19
    bcc @copy
    stz ERR_LO
    stz ERR_HI
    stz BAD_SEEN
    lda #1
    sta PASS_NO

next_pass:
    stz PHASE_NO
    jsr scan_all
    lda #1
    sta PHASE_NO
    jsr scan_all
    inc PASS_NO
    lda PASS_NO
    cmp #7
    bcs @all_finished
    jmp next_pass
@all_finished:

    ; Final display, remains until reset.
    lda #'D'
    sta LINE2+9
    lda #'O'
    sta LINE2+10
    lda #'N'
    sta LINE2+11
    lda #'E'
    sta LINE2+12
    lda #0
    sta LINE2+13
    jsr refresh_oled
stop:
    jmp stop

; Scans ALL banks for this phase. Fill whole 512K before checking.
scan_all:
    lda #$08
    sta RAM_PTR+2
@bank:
    stz RAM_PTR
    stz RAM_PTR+1
    jsr refresh_status
@page:
    ldy #0
    lda PHASE_NO
    beq @write
@check:
    jsr make_expected
    sta EXPECTED
    lda [RAM_PTR],y
    cmp EXPECTED
    beq @good
    sta ACTUAL
    jsr record_error
@good:
    iny
    bne @check
    bra @page_done
@write:
    jsr make_expected
    sta [RAM_PTR],y
    iny
    bne @write
@page_done:
    inc RAM_PTR+1
    lda RAM_PTR+1
    beq @next_bank
    and #$3F            ; redraw at page 40,80,C0
    bne @page
    jsr refresh_status
    bra @page
@next_bank:
    inc RAM_PTR+2
    lda RAM_PTR+2
    cmp #$10
    beq @done
    jmp @bank
@done:
    rts

; A = expected byte according to pass, bank, page and offset Y.
make_expected:
    lda PASS_NO
    cmp #1
    bne @not1
    lda #$00
    rts
@not1:
    cmp #2
    bne @not2
    lda #$FF
    rts
@not2:
    cmp #3
    bne @not3
    lda #$AA
    rts
@not3:
    cmp #4
    bne @address
    lda #$55
    rts
@address:
    tya
    eor RAM_PTR+1
    eor RAM_PTR+2
    pha
    lda PASS_NO
    cmp #6
    bne @normal
    pla
    eor #$FF
    rts
@normal:
    pla
    rts

record_error:
    ; ERR count saturates at FFFF, preserving address and data.
    lda ERR_LO
    cmp #$FF
    bne @increment
    lda ERR_HI
    cmp #$FF
    beq @store
@increment:
    inc ERR_LO
    bne @store
    inc ERR_HI
@store:
    lda RAM_PTR+2
    sta BAD_BANK
    lda RAM_PTR+1
    sta BAD_HI
    tya
    sta BAD_LO
    lda EXPECTED
    sta BAD_EXP
    lda ACTUAL
    sta BAD_ACT
    lda #1
    sta BAD_SEEN
    rts

hex_digit:
    and #$0F
    cmp #10
    bcc @decimal
    clc
    adc #('A'-10)
    rts
@decimal:
    clc
    adc #'0'
    rts

; A = byte, X = position within line, Y = line selector 0..3
; Nibble conversion writes text using a direct-page pointer.
puthex:
    pha
    lsr a
    lsr a
    lsr a
    lsr a
    jsr hex_digit
    jsr put_char
    inx
    pla
    and #$0F
    jsr hex_digit
    jsr put_char
    rts

put_char:
    ; A=ASCII, Y=line selector, X=column. Compute pointer in DP.
    pha
    tya
    asl a
    asl a
    asl a
    asl a
    asl a                ; y*32
    clc
    adc #<LINE1
    sta TEXT_PTR
    lda #>LINE1
    sta TEXT_PTR+1
    txa
    clc
    adc TEXT_PTR
    sta TEXT_PTR
    bcc @no_carry
    inc TEXT_PTR+1
@no_carry:
    pla
    phx
    ldx #0
    sta (TEXT_PTR,x)
    plx
    rts

refresh_status:
    ; line 1: "512K ERR:0000"
    ldy #0
    ldx #9
    lda ERR_HI
    jsr puthex
    ldx #11
    lda ERR_LO
    jsr puthex
    ; line 2: "PASS:1/6 WRITE" or CHECK
    ldy #1
    ldx #5
    lda PASS_NO
    clc
    adc #'0'
    jsr put_char
    lda PHASE_NO
    beq @write_label
    ldx #9
    lda #'C'
    jsr put_char
    inx
    lda #'H'
    jsr put_char
    inx
    lda #'E'
    jsr put_char
    inx
    lda #'C'
    jsr put_char
    inx
    lda #'K'
    jsr put_char
    bra @phase_done
@write_label:
    ldx #9
    lda #'W'
    jsr put_char
    inx
    lda #'R'
    jsr put_char
    inx
    lda #'I'
    jsr put_char
    inx
    lda #'T'
    jsr put_char
    inx
    lda #'E'
    jsr put_char
@phase_done:
    ldy #2
    ldx #5
    lda RAM_PTR+2
    jsr puthex
    ldx #13
    lda RAM_PTR+1
    jsr puthex
    lda BAD_SEEN
    beq @draw
    ; Last bad address + expected/actual bytes.
    ldy #3
    ldx #4
    lda BAD_BANK
    jsr puthex
    ldx #7
    lda BAD_HI
    jsr puthex
    ldx #9
    lda BAD_LO
    jsr puthex
    ldx #12
    lda BAD_EXP
    jsr puthex
    ldx #15
    lda BAD_ACT
    jsr puthex
@draw:
    jmp refresh_oled

refresh_oled:
    lda #0
    sta PAGE_NO
    lda #<LINE1
    sta TEXT_PTR
    lda #>LINE1
    sta TEXT_PTR+1
    jsr print_line
    lda #2
    sta PAGE_NO
    lda #<LINE2
    sta TEXT_PTR
    lda #>LINE2
    sta TEXT_PTR+1
    jsr print_line
    lda #4
    sta PAGE_NO
    lda #<LINE3
    sta TEXT_PTR
    lda #>LINE3
    sta TEXT_PTR+1
    jsr print_line
    lda #6
    sta PAGE_NO
    lda #<LINE4
    sta TEXT_PTR
    lda #>LINE4
    sta TEXT_PTR+1
    jmp print_line


oled_cmd:
    pha
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$00                ; command control byte
    jsr i2c_write
    pla
    jsr i2c_write
    jmp i2c_stop

; A = page 0 through 7, set column 0
oled_position:
    ora #$B0
    jsr oled_cmd
    lda #$00
    jsr oled_cmd
    lda #$10
    jmp oled_cmd

oled_data_begin:
    jsr i2c_start
    lda #OLED_WRITE
    jsr i2c_write
    lda #$40                ; data control byte
    jmp i2c_write

; TEXT_PTR points to zero-terminated text, max 21 characters.
; Glyphs are 5 columns plus 1 blank.
print_line:
    lda PAGE_NO
    jsr oled_position
    jsr oled_data_begin
    stz TEXT_INDEX
@next_char:
    ldy TEXT_INDEX
    lda (TEXT_PTR),y
    beq @end
    sta CHAR_VALUE
    ; Look up glyph in table, default to blank.
    ldx #0
@find:
    lda font_chars,x
    beq @space
    cmp CHAR_VALUE
    beq @found
    inx
    bra @find
@space:
    ldx #0
@found:
    ; X = character index; multiply by 5.
    txa
    sta FONT_OFFSET
    asl a
    asl a
    clc
    adc FONT_OFFSET
    tax
    lda #5
    sta GLYPH_COUNT
@draw:
    lda font_data,x
    phx
    jsr i2c_write
    plx
    inx
    dec GLYPH_COUNT
    bne @draw
    lda #0
    jsr i2c_write
    inc TEXT_INDEX
    lda TEXT_INDEX
    cmp #21
    bcc @next_char
@end:
    jmp i2c_stop


; SSD1306 init 128x64, horizontal page addressing.
init_cmds:
    .byte $AE,$D5,$80,$A8,$3F,$D3,$00,$40,$8D,$14
    .byte $20,$02,$A1,$C8,$DA,$12,$81,$CF,$D9,$F1
    .byte $DB,$40,$A4,$A6,$2E,$AF,$FF

; Each template copied to bank-0 RAM at startup (19 bytes).
template1: .asciiz "512K ERR:0000"
template2: .asciiz "PASS:1/6 WRITE"
template3: .asciiz "BANK:08 PAGE:00"
template4: .asciiz "BAD:--:---- --/--"

font_chars: .byte " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789:/-",0
font_data:
    .byte $00,$00,$00,$00,$00 ;  
    .byte $7E,$11,$11,$11,$7E ; A
    .byte $7F,$49,$49,$49,$36 ; B
    .byte $3E,$41,$41,$41,$22 ; C
    .byte $7F,$41,$41,$22,$1C ; D
    .byte $7F,$49,$49,$49,$41 ; E
    .byte $7F,$09,$09,$09,$01 ; F
    .byte $3E,$41,$49,$49,$7A ; G
    .byte $7F,$08,$08,$08,$7F ; H
    .byte $00,$41,$7F,$41,$00 ; I
    .byte $20,$40,$41,$3F,$01 ; J
    .byte $7F,$08,$14,$22,$41 ; K
    .byte $7F,$40,$40,$40,$40 ; L
    .byte $7F,$02,$0C,$02,$7F ; M
    .byte $7F,$04,$08,$10,$7F ; N
    .byte $3E,$41,$41,$41,$3E ; O
    .byte $7F,$09,$09,$09,$06 ; P
    .byte $3E,$41,$51,$21,$5E ; Q
    .byte $7F,$09,$19,$29,$46 ; R
    .byte $46,$49,$49,$49,$31 ; S
    .byte $01,$01,$7F,$01,$01 ; T
    .byte $3F,$40,$40,$40,$3F ; U
    .byte $1F,$20,$40,$20,$1F ; V
    .byte $3F,$40,$38,$40,$3F ; W
    .byte $63,$14,$08,$14,$63 ; X
    .byte $07,$08,$70,$08,$07 ; Y
    .byte $61,$51,$49,$45,$43 ; Z
    .byte $3E,$51,$49,$45,$3E ; 0
    .byte $00,$42,$7F,$40,$00 ; 1
    .byte $62,$51,$49,$49,$46 ; 2
    .byte $22,$41,$49,$49,$36 ; 3
    .byte $18,$14,$12,$7F,$10 ; 4
    .byte $27,$45,$45,$45,$39 ; 5
    .byte $3C,$4A,$49,$49,$30 ; 6
    .byte $01,$71,$09,$05,$03 ; 7
    .byte $36,$49,$49,$49,$36 ; 8
    .byte $06,$49,$49,$29,$1E ; 9
    .byte $00,$36,$36,$00,$00 ; :
    .byte $20,$10,$08,$04,$02 ; /
    .byte $08,$08,$08,$08,$08 ; -

; Single-master bit-banged I2C for EDU VIA PA0 / PA7.
; Direction switching implements open-drain, with the EDU pull-ups.
; Does not support clock stretching or multi-master arbitration.
; Clobbers A,Y and scratch $00E7. Preserves X.


i2c_delay:
    phx
    ldx #20
@wait:
    dex
    bne @wait
    plx
    rts

i2c_init:
    lda VIA_ORA
    and #$7E
    sta VIA_ORA             ; Output latch remains low on SDA and SCL
    lda VIA_DDRA
    and #$7E
    sta VIA_DDRA            ; Both lines released
    jmp i2c_delay

i2c_start:
    jsr i2c_init
    lda VIA_DDRA
    ora #I2C_SDA
    sta VIA_DDRA            ; SDA low while SCL high
    jsr i2c_delay
    lda VIA_DDRA
    ora #I2C_SCL
    sta VIA_DDRA
    jmp i2c_delay

i2c_stop:
    lda VIA_DDRA
    ora #$81
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_DDRA
    and #$FE
    sta VIA_DDRA            ; SCL high
    jsr i2c_delay
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; SDA high
    jmp i2c_delay

; Input A=byte. Output carry clear=ACK, set=NACK.
i2c_write:
    sta I2C_BYTE
    ldy #8
@bit:
    asl I2C_BYTE
    lda VIA_DDRA
    bcs @one
    ora #$80
    bra @data
@one:
    and #$7F
@data:
    sta VIA_DDRA
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    dey
    bne @bit
    lda VIA_DDRA
    and #$7F
    sta VIA_DDRA            ; Release SDA for slave ACK
    jsr i2c_delay
    and #$FE
    sta VIA_DDRA
    jsr i2c_delay
    lda VIA_ORA
    and #$80
    pha
    lda VIA_DDRA
    ora #1
    sta VIA_DDRA
    jsr i2c_delay
    pla
    beq @ack
    sec
    rts
@ack:
    clc
    rts

