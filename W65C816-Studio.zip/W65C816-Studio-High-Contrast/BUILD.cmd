@echo off
cd /d "%~dp0"
dotnet publish Studio/Studio.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
pause
