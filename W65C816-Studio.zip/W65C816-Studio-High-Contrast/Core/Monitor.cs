using System.IO.Ports;
namespace W65C816;

public interface IMonitorWire : IDisposable
{
    void Write(byte[] bytes);
    byte[] Read(int count);
}

public sealed class SerialWire : IMonitorWire
{
    private readonly SerialPort port;
    public SerialWire(string name)
    {
        port = new SerialPort(name, 115200, Parity.None, 8, StopBits.One)
        { ReadTimeout = 3000, WriteTimeout = 3000, Handshake = Handshake.None, DtrEnable = false, RtsEnable = false };
        try { port.Open(); } catch { port.Dispose(); throw; }
    }
    public void Write(byte[] bytes) => port.Write(bytes, 0, bytes.Length);
    public byte[] Read(int count)
    {
        var data = new byte[count];
        var read = 0;
        while (read < count) read += port.Read(data, read, count - read);
        return data;
    }
    public void Dispose() => port.Dispose();
}

// WDC factory ROM 2.0.4.3 protocol; all writes are restricted to application RAM/context.
public sealed class BoardMonitor(IMonitorWire wire)
{
    public const int Origin = 0x2000;
    public const int MaxImage = 0x5E00;
    private void Sync()
    {
        wire.Write([0x55, 0xAA]);
        // Reset, BRK and NMI notifications may be queued before the sync reply.
        for (int i = 0; i < 8; i++)
        {
            var reply = wire.Read(1)[0];
            if (reply == 0xCC) return;
            if (reply is not (0xFF or 0x02 or 0x07)) break;
        }
        throw new IOException("Board did not acknowledge the monitor handshake. Press RESET / S2 and retry.");
    }
    private byte[] Transfer(byte cmd, int address, int count, byte[]? data = null)
    {
        Sync();
        byte[] header = [cmd, (byte)address, (byte)(address >> 8), (byte)(address >> 16), (byte)count, (byte)(count >> 8)];
        wire.Write(header);
        if (data is not null) wire.Write(data);
        return cmd == 3 ? wire.Read(count) : [];
    }
    public byte[] ReadResults() => Transfer(3, 0x3000, 512);
    public void Check()
    {
        Sync(); wire.Write([0]);
        if (wire.Read(1)[0] != 0) throw new IOException("Unexpected monitor sync response.");
    }
    public void Upload(byte[] image, bool run, Action<string>? log = null)
    {
        if (image.Length == 0 || image.Length > MaxImage)
            throw new ArgumentException("Program must fit in RAM $2000–$7DFF (1–24064 bytes).");
        log?.Invoke($"Uploading {image.Length:N0} bytes to $2000…");
        Transfer(2, Origin, image.Length, image);
        if (!Transfer(3, Origin, image.Length).SequenceEqual(image))
            throw new IOException("Program verification failed. Execution was not started.");
        log?.Invoke("Program verified byte for byte.");
        // A X Y PC DP SP P E PB DB, little endian. Emulation mode, IRQ disabled.
        byte[] context = [0,0, 0,0, 0,0, 0,0x20, 0,0, 0xFF,1, 0x34,1,0,0];
        Transfer(2, 0x7E00, context.Length, context);
        if (!Transfer(3, 0x7E00, context.Length).SequenceEqual(context))
            throw new IOException("CPU context verification failed. Execution was not started.");
        if (run) RunLoadedProgram(log);
        else log?.Invoke("Upload complete. Board remains in the monitor.");
    }

    // Keep execution distinct from RAM transfer: the monitor must finish the
    // final verification read before accepting the GO command.
    public void RunLoadedProgram(Action<string>? log = null)
    {
        Sync();
        wire.Write([5]);
        log?.Invoke("GO command sent • PC=$2000 • bank 0 • emulation mode.");
    }
}
