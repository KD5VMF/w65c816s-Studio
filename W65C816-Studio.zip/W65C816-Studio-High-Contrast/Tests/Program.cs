using W65C816;
int passed = 0;
void Test(string name, Action test) { test(); Console.WriteLine("PASS " + name); passed++; }
void Assert(bool test, string message = "Assertion failed") { if (!test) throw new Exception(message); }
void Fails(Action action) { bool failed = false; try { action(); } catch { failed = true; } Assert(failed, "Expected failure"); }
var sample = Enumerable.Range(0, 115).Select(n => (byte)n).ToArray();
Test("Full RAM upload, CPU context and execution", () => {
 using var wire = new FakeWire(); new BoardMonitor(wire).Upload(sample, true);
 Assert(wire.Memory.AsSpan(0x2000, sample.Length).SequenceEqual(sample));
 Assert(wire.Memory.AsSpan(0x7E00, 16).SequenceEqual(new byte[] {0,0,0,0,0,0,0,0x20,0,0,0xFF,1,0x34,1,0,0}));
 Assert(wire.Executed); Assert(wire.Writes == 2);
});
Test("Upload only never executes", () => { using var wire = new FakeWire(); new BoardMonitor(wire).Upload(sample, false); Assert(!wire.Executed); });
Test("One-click sequential upload and GO", () => {
 using var wire = new FakeWire(); var monitor = new BoardMonitor(wire);
 monitor.Upload(sample, false);
 Assert(!wire.Executed && wire.Writes == 2, "Upload/verify must finish before GO");
 monitor.RunLoadedProgram();
 Assert(wire.Executed && wire.Writes == 2, "GO should execute without another upload");
});
Test("Corrupt program is never executed", () => { using var wire = new FakeWire { CorruptAddress = 0x2000 }; Fails(() => new BoardMonitor(wire).Upload(sample, true)); Assert(!wire.Executed && wire.Writes == 1); });
Test("Corrupt context is never executed", () => { using var wire = new FakeWire { CorruptAddress = 0x7E00 }; Fails(() => new BoardMonitor(wire).Upload(sample, true)); Assert(!wire.Executed); });
Test("Empty and oversized programs rejected before I/O", () => { using var wire = new FakeWire(); var m = new BoardMonitor(wire); Fails(() => m.Upload([], true)); Fails(() => m.Upload(new byte[BoardMonitor.MaxImage+1], true)); Assert(wire.Writes == 0 && !wire.Executed); });
Test("Maximum image fits exactly below monitor RAM", () => { using var wire = new FakeWire(); new BoardMonitor(wire).Upload(new byte[BoardMonitor.MaxImage], true); Assert(wire.Executed); });
Test("Reset/BRK notifications do not break sync", () => { using var wire = new FakeWire(); wire.Output.Enqueue(0xFF); wire.Output.Enqueue(2); new BoardMonitor(wire).Check(); });
Test("Read EDU results without writing RAM", () => { using var wire = new FakeWire(); wire.Memory[0x3000]=0xA5; wire.Memory[0x3100]=0x6F; var data = new BoardMonitor(wire).ReadResults(); Assert(data.Length == 512 && data[0] == 0xA5 && data[256] == 0x6F && wire.Writes == 0); });
Console.WriteLine($"{passed} protocol tests passed.");

sealed class FakeWire : IMonitorWire
{
 public byte[] Memory { get; } = new byte[65536];
 public Queue<byte> Output { get; } = new();
 private List<byte> incoming = [];
 private int state, cmd, address, count;
 public int? CorruptAddress { get; init; }
 public bool Executed { get; private set; }
 public int Writes { get; private set; }
 public void Write(byte[] bytes)
 {
  incoming.AddRange(bytes);
  bool progress = true;
  while(progress)
  {
   progress = false;
   if(state == 0 && incoming.Count >= 2)
   {
    if(incoming[0]!=0x55 || incoming[1]!=0xAA) throw new Exception("Bad sync request");
    incoming.RemoveRange(0,2); Output.Enqueue(0xCC); state=1;progress=true;
   }
   if(state==1 && incoming.Count>=1)
   {
    cmd=incoming[0];incoming.RemoveAt(0);progress=true;
    if(cmd==5) {Executed=true;state=0;}
    else if(cmd==0) {Output.Enqueue(0);state=0;}
    else if(cmd is 2 or 3) state=2;
    else throw new Exception("Unexpected command");
   }
   if(state==2 && incoming.Count>=5)
   {
    address=incoming[0]|incoming[1]<<8|incoming[2]<<16;count=incoming[3]|incoming[4]<<8;
    incoming.RemoveRange(0,5);progress=true;
    if(cmd==3)
    {
     for(int i=0;i<count;i++) Output.Enqueue((byte)(Memory[address+i] ^ (CorruptAddress==address && i==0 ? 1:0)));
     state=0;
    } else state=3;
   }
   if(state==3 && incoming.Count>=count)
   {
    if(!((address>=0x2000 && address+count<=0x7E00) || (address==0x7E00 && count==16))) throw new Exception("Unsafe RAM write");
    incoming.CopyTo(0,Memory,address,count);incoming.RemoveRange(0,count);Writes++;state=0;progress=true;
   }
  }
 }
 public byte[] Read(int count)
 {
  if(Output.Count<count) throw new TimeoutException("No data from emulated board");
  return Enumerable.Range(0,count).Select(_=>Output.Dequeue()).ToArray();
 }
 public void Dispose() { }
}
