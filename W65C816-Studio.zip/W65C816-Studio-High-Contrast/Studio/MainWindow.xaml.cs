using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using System.Xml;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using ICSharpCode.AvalonEdit.Search;
using Microsoft.Win32;
namespace W65C816.Studio;

public partial class MainWindow : Window
{
    private readonly string appRoot = AppContext.BaseDirectory;
    private readonly string workRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "W65C816 Studio");
    private string VerifiedExamplesRoot => Path.Combine(workRoot, "Studio Examples - Verified");
    private readonly string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "W65C816Studio", "settings.json");
    private string? filePath;
    private bool dirty, loading, busy;
    private SearchPanel? search;
    private string outputDirectory = "";
    private Preferences preferences = new();
    public MainWindow()
    {
        InitializeComponent();
        Editor.Options.ConvertTabsToSpaces = true;
        Editor.Options.IndentationSize = 4;
        Editor.Options.HighlightCurrentLine = true;
        Editor.TextArea.SelectionBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(184, 216, 247));
        search = SearchPanel.Install(Editor);
        using var reader = XmlReader.Create(new StringReader(SyntaxXml));
        Editor.SyntaxHighlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
        Editor.TextArea.Caret.PositionChanged += (_, _) => CaretLabel.Text = $"Ln {Editor.TextArea.Caret.Line}, Col {Editor.TextArea.Caret.Column}";
        PreviewKeyDown += Keyboard;
        Loaded += (_, _) => InitializeWorkspace();
    }
    private void InitializeWorkspace()
    {
        try
        {
            Directory.CreateDirectory(workRoot);
            RefreshVerifiedExamples();
            try { preferences = JsonSerializer.Deserialize<Preferences>(File.ReadAllText(settingsPath)) ?? new(); } catch { }
            RefreshPorts();
            Profile.SelectedIndex = preferences.Edu ? 1 : 0;
            // Old releases wrote samples directly to Documents, and did not update
            // those files on subsequent launches. Never trust an old sample path.
            var initial = preferences.File;
            if (string.IsNullOrWhiteSpace(initial) || !File.Exists(initial))
                initial = Path.Combine(VerifiedExamplesRoot, "EDU-LEDs.s");
            else if (string.Equals(Path.GetDirectoryName(Path.GetFullPath(initial)),
                         Path.GetFullPath(workRoot), StringComparison.OrdinalIgnoreCase)
                     && File.Exists(Path.Combine(appRoot, "examples", Path.GetFileName(initial))))
            {
                Log("Previous example in Documents may be stale. Opening the verified version instead; original left untouched: " + initial);
                initial = Path.Combine(VerifiedExamplesRoot, Path.GetFileName(initial));
            }
            LoadFile(initial);
            Log("Welcome to W65C816 Studio. F6 builds; F5 builds, uploads and runs.");
            Log("Select your USB COM port. Press RESET on the SXB or EDU before uploading while a program is running.");
        }
        catch (Exception e) { Report(e); }
    }
    // Samples live in a dedicated workspace folder; older root-level copies are
    // retained without modification. Refresh managed examples from the release.
    // If a user edited a managed example, preserve it before replacing it.
    private void RefreshVerifiedExamples()
    {
        var bundled = Path.Combine(appRoot, "examples");
        if (!Directory.Exists(bundled)) throw new DirectoryNotFoundException("Bundled examples missing: " + bundled);
        Directory.CreateDirectory(VerifiedExamplesRoot);
        foreach (var source in Directory.GetFiles(bundled))
        {
            var dest = Path.Combine(VerifiedExamplesRoot, Path.GetFileName(source));
            if (File.Exists(dest) && File.ReadAllBytes(source).AsSpan().SequenceEqual(File.ReadAllBytes(dest))) continue;
            if (File.Exists(dest))
            {
                var backupFolder = Path.Combine(workRoot, "Example Backups");
                Directory.CreateDirectory(backupFolder);
                var name = Path.GetFileName(source);
                var backup = Path.Combine(backupFolder, DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "-" + name);
                while (File.Exists(backup)) backup = Path.Combine(backupFolder, Guid.NewGuid().ToString("N") + "-" + name);
                File.Copy(dest, backup);
                Log("Saved modified example backup: " + backup);
            }
            File.Copy(source, dest, true);
        }
    }
    private void RefreshPorts()
    {
        var previous = Ports.SelectedItem as string ?? preferences.Port;
        var names = SerialPort.GetPortNames().OrderBy(s => s.Length).ThenBy(s => s).ToArray();
        Ports.ItemsSource = names;
        if (names.Contains(previous)) Ports.SelectedItem = previous;
        else if (names.Length == 1) Ports.SelectedIndex = 0;
        else Ports.SelectedIndex = -1;
        Status.Text = names.Length == 0 ? "No COM ports found • connect your board and refresh" : "Ready • select your board's USB port";
    }
    private void LoadFile(string path)
    {
        var text = File.ReadAllText(path);
        loading = true; Editor.Text = text; loading = false;
        filePath = path; dirty = false; UpdateTitle();
    }
    private void UpdateTitle()
    {
        if (FileLabel is null) return;
        FileLabel.Text = (filePath is null ? "Untitled.s" : Path.GetFileName(filePath)) + (dirty ? "  ●" : "");
        FileLabel.ToolTip = filePath;
        Title = FileLabel.Text + " — W65C816 Studio";
    }
    private bool Save(bool saveAs = false)
    {
        try
        {
            var destination = filePath;
            if (destination is null || saveAs)
            {
                var dialog = new SaveFileDialog { Filter = "65816 assembly|*.s;*.asm|All files|*.*", DefaultExt = ".s", FileName = filePath is null ? "main.s" : Path.GetFileName(filePath), InitialDirectory = filePath is null ? workRoot : Path.GetDirectoryName(filePath) };
                if (dialog.ShowDialog(this) != true) return false;
                destination = dialog.FileName;
            }
            File.WriteAllText(destination, Editor.Text, new UTF8Encoding(false));
            filePath = destination; dirty = false; UpdateTitle(); return true;
        }
        catch (Exception e) { Report(e); return false; }
    }
    private bool CanReplace()
    {
        if (busy) return false;
        if (!dirty) return true;
        var result = MessageBox.Show(this, "Save your changes before continuing?", "Unsaved source", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        return result == MessageBoxResult.No || result == MessageBoxResult.Yes && Save();
    }
    private void SetBusy(bool state)
    {
        busy = state;
        BuildButton.IsEnabled = UploadButton.IsEnabled = RunButton.IsEnabled = CheckButton.IsEnabled = !state;
        Ports.IsEnabled = Profile.IsEnabled = Samples.IsEnabled = !state;
        Editor.IsReadOnly = state;
        if (state) Status.Text = "Working…";
    }
    private void Log(string message) => Dispatcher.Invoke(() => { Output.AppendText(message + Environment.NewLine); Output.ScrollToEnd(); });
    private void Report(Exception e)
    {
        var message = e is TimeoutException ? "Monitor timeout. Press RESET / S2 (RESB on EDU), close other serial apps, check the COM port, and retry." : e.Message;
        Log("ERROR: " + message); Status.Text = "Failed • see build output"; OutputTabs.SelectedIndex = 0;
    }
    private async Task<int> RunTool(string name, params string[] args)
    {
        var start = new ProcessStartInfo(Path.Combine(appRoot, "tools", name))
        { WorkingDirectory = Path.GetDirectoryName(filePath)!, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var arg in args) start.ArgumentList.Add(arg);
        using var process = Process.Start(start) ?? throw new IOException("Could not start " + name);
        async Task Drain(StreamReader stream) { while (await stream.ReadLineAsync() is { } line) Log(line); }
        var stdout = Drain(process.StandardOutput); var stderr = Drain(process.StandardError);
        try { await process.WaitForExitAsync(new CancellationTokenSource(TimeSpan.FromSeconds(45)).Token); }
        catch (OperationCanceledException) { process.Kill(true); throw new IOException(name + " exceeded its build timeout."); }
        await Task.WhenAll(stdout, stderr);
        return process.ExitCode;
    }
    private async Task BuildAndUpload(bool upload, bool run)
    {
        if (busy) return;
        string? port = Ports.SelectedItem as string;
        if (upload && port is null) { Log("Choose your board's COM port before uploading."); Status.Text = "Select a USB port"; return; }
        if (!Save()) return;
        Output.Clear(); Listing.Clear(); Hex.Clear(); OutputTabs.SelectedIndex = 0;
        SetBusy(true);
        try
        {
            outputDirectory = Path.Combine(Path.GetDirectoryName(filePath)!, ".w65c816-build");
            Directory.CreateDirectory(outputDirectory);
            var stem = Path.Combine(outputDirectory, Path.GetFileNameWithoutExtension(filePath!));
            Log("Assembling " + filePath);
            if (await RunTool("ca65.exe", "--cpu", "65816", "-I", Path.Combine(appRoot, "examples"), "-g", "-l", stem + ".lst", "-o", stem + ".o", filePath!) != 0) throw new IOException("Assembly failed. Double-click an error line to jump to it.");
            if (await RunTool("ld65.exe", "-C", Path.Combine(appRoot, "tools", "board.cfg"), "-m", stem + ".map", "--dbgfile", stem + ".dbg", "-Ln", stem + ".lbl", "-o", stem + ".bin", stem + ".o") != 0) throw new IOException("Link failed. Check output and RAM capacity.");
            var image = await File.ReadAllBytesAsync(stem + ".bin");
            Listing.Text = await File.ReadAllTextAsync(stem + ".lst");
            var hex = new StringBuilder();
            for (var offset = 0; offset < image.Length; offset += 16)
                hex.AppendLine($"{0x2000 + offset:X6}   {string.Join(" ", image.Skip(offset).Take(16).Select(b => b.ToString("X2")))}");
            Hex.Text = hex.ToString();
            Log($"Build succeeded • {image.Length:N0} / {BoardMonitor.MaxImage:N0} bytes • entry $2000");
            if (upload)
            {
                Log($"Opening {port} • loading application RAM…");
                Status.Text = "Build succeeded • uploading…";
                await Task.Run(() =>
                {
                    using var wire = new SerialWire(port!);
                    var monitor = new BoardMonitor(wire);
                    // Always complete the upload and byte-for-byte verification
                    // before attempting GO. One click runs both phases.
                    monitor.Upload(image, false, Log);
                    if (run)
                    {
                        Log("Upload verified • starting the CPU…");
                        // Give the board time to return to its monitor command
                        // loop after the final RAM/context read.
                        Thread.Sleep(100);
                        monitor.RunLoadedProgram(Log);
                    }
                });
                Status.Text = run ? "Build + upload verified • GO sent to board" : "Build + upload verified • program stopped";
                Log(run ? "Build & Run finished: program started (GO sent)." : "Upload only finished: ready to run from monitor.");
            }
            else Status.Text = "Build succeeded";
        }
        catch (Exception e) { Report(e); }
        finally { SetBusy(false); }
    }
    private async void CheckClick(object sender, RoutedEventArgs e)
    {
        if (busy) return;
        if (Ports.SelectedItem is not string port) { Log("Select a USB port first."); return; }
        SetBusy(true);
        try { await Task.Run(() => { using var wire = new SerialWire(port); new BoardMonitor(wire).Check(); }); Log("Board monitor acknowledged on " + port); Status.Text = "Monitor responding on " + port; }
        catch (Exception ex) { Report(ex); }
        finally { SetBusy(false); }
    }
    private async void ReadResultsClick(object sender, RoutedEventArgs e)
    {
        if (busy) return;
        if (Ports.SelectedItem is not string port) { Log("Select a USB port first."); return; }
        SetBusy(true);
        try
        {
            var data = await Task.Run(() => { using var wire = new SerialWire(port); return new BoardMonitor(wire).ReadResults(); });
            var text = new StringBuilder("Bank 0 • $3000–$31FF\nRAM check: $3000=A5 pass / FF fail. I²C scan: $3000=count, $3100=addresses.\n\n");
            for (int i = 0; i < data.Length; i += 16)
                text.AppendLine($"{0x3000 + i:X6}  {string.Join(" ", data.Skip(i).Take(16).Select(b => b.ToString("X2")))}");
            Results.Text = text.ToString(); OutputTabs.SelectedIndex = 4;
            Status.Text = "Read 512 bytes of result RAM";
        }
        catch (Exception ex) { Report(ex); }
        finally { SetBusy(false); }
    }
    private async void BuildClick(object s, RoutedEventArgs e) => await BuildAndUpload(false, false);
    private async void RunClick(object s, RoutedEventArgs e) => await BuildAndUpload(true, true);
    private async void UploadOnlyClick(object s, RoutedEventArgs e) => await BuildAndUpload(true, false);
    private void RefreshClick(object s, RoutedEventArgs e) { if (!busy) try { RefreshPorts(); } catch (Exception ex) { Report(ex); } }
    private void SaveClick(object s, RoutedEventArgs e) { if (!busy) Save(); }
    private void SaveAsClick(object s, RoutedEventArgs e) { if (!busy) Save(true); }
    private void FindClick(object s, RoutedEventArgs e) => OpenFind();
    private void OpenFind()
    {
        // SearchPanel.Open() focuses its search field. Calling Editor.Focus()
        // afterward steals focus and makes the Find button appear broken.
        // The editor must retain its selection, but NOT take input focus.
        search?.Open();
    }
    private void OpenClick(object s, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        var dialog = new OpenFileDialog { Filter = "65816 assembly|*.s;*.asm|All files|*.*", InitialDirectory = workRoot };
        if (dialog.ShowDialog(this) == true) try { LoadFile(dialog.FileName); } catch (Exception ex) { Report(ex); }
    }
    private void NewClick(object s, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        loading = true;
        Editor.Text = ".setcpu \"65816\"\n.a8\n.i8\n.segment \"CODE\"\nstart:\n    sei\n    sec\n    xce\n    cld\n\n    ; Your code here. Entry is $2000.\n\n    brk\n    .byte 0\n";
        loading = false; filePath = null; dirty = true; UpdateTitle();
    }
    private void ExampleClick(object s, RoutedEventArgs e)
    {
        if (!CanReplace()) return;
        try
        {
            var selected = (Samples.SelectedItem as Sample)?.File ?? "LED-Sweep.s";
            RefreshVerifiedExamples();
            LoadFile(Path.Combine(VerifiedExamplesRoot, selected));
            Log("Loaded verified example: " + selected);
        }
        catch (Exception ex) { Report(ex); }
    }
    private void GuideClick(object s, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo { FileName = Path.Combine(appRoot, "EDU-GUIDE.html"), UseShellExecute = true }); } catch (Exception ex) { Report(ex); }
    }
    private void OutputFolderClick(object s, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo { FileName = Directory.Exists(outputDirectory) ? outputDirectory : workRoot, UseShellExecute = true }); } catch (Exception ex) { Report(ex); }
    }
    private void EditorChanged(object? s, EventArgs e) { if (!loading) dirty = true; UpdateTitle(); }
    private async void Keyboard(object s, KeyEventArgs e)
    {
        if (busy) return;
        var ctrl = (KeyboardModifiers() & ModifierKeys.Control) != 0;
        if (e.Key == Key.F5) { e.Handled = true; await BuildAndUpload(true, true); }
        else if (e.Key == Key.F6) { e.Handled = true; await BuildAndUpload(false, false); }
        else if (ctrl && e.Key == Key.F) { e.Handled = true; OpenFind(); }
        else if (ctrl && e.Key == Key.S) { e.Handled = true; Save((KeyboardModifiers() & ModifierKeys.Shift) != 0); }
        else if (ctrl && e.Key == Key.O) { e.Handled = true; OpenClick(s, e); }
        else if (ctrl && e.Key == Key.N) { e.Handled = true; NewClick(s, e); }
    }
    private static ModifierKeys KeyboardModifiers() => System.Windows.Input.Keyboard.Modifiers;
    private void OutputDoubleClick(object s, MouseButtonEventArgs e)
    {
        var index = Output.GetLineIndexFromCharacterIndex(Output.CaretIndex);
        if (index < 0) return;
        var match = Regex.Match(Output.GetLineText(index), @"^(.+)\((\d+)\):");
        if (!match.Success) return;
        var path = match.Groups[1].Value;
        if (!Path.IsPathRooted(path)) path = Path.Combine(Path.GetDirectoryName(filePath)!, path);
        if (!string.Equals(Path.GetFullPath(path), filePath, StringComparison.OrdinalIgnoreCase)) { Log("Error is in include file: " + path); return; }
        var line = Math.Clamp(int.Parse(match.Groups[2].Value), 1, Editor.Document.LineCount);
        Editor.ScrollToLine(line); Editor.TextArea.Caret.Line = line; Editor.Focus();
    }
    private void OnClosing(object? s, CancelEventArgs e)
    {
        if (busy) { e.Cancel = true; Status.Text = "Wait for the current operation before closing"; return; }
        if (!CanReplace()) { e.Cancel = true; return; }
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath)!);
            File.WriteAllText(settingsPath, JsonSerializer.Serialize(new Preferences { File = filePath, Port = Ports.SelectedItem as string, Edu = Profile.SelectedIndex == 1 }));
        } catch { }
    }
    private void ProfileChanged(object s, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (Samples is null) return;
        var edu = Profile.SelectedIndex == 1;
        Samples.ItemsSource = edu ? new Sample[] { new("EDU · 8 LED chase", "EDU-LEDs.s"), new("EDU · Buzzer beep", "EDU-Buzzer.s"), new("EDU · Banked RAM check", "EDU-RAM.s"), new("EDU · I²C bus scan", "EDU-I2C-Scan.s"), new("EDU · SPI RAM check", "EDU-SPI-RAM.s"), new("EDU · OLED text demo", "EDU-OLED-Text.s"), new("EDU · OLED 512K RAM test", "EDU-OLED-512K-RAM-Test.s"), new("EDU · OLED RTC clock", "EDU-OLED-RTC-Clock.s"), new("EDU · Large Fahrenheit temperature", "EDU-OLED-Temperature-F.s"), new("EDU · OLED primes to 1 million", "EDU-OLED-Primes-1Million.s"), new("SXB · X LED sweep", "LED-Sweep.s") } : new Sample[] { new("SXB · X LED sweep", "LED-Sweep.s") };
        Samples.SelectedIndex = 0;
        if (Reference is not null) Reference.Text = edu ? EduReference : "SXB application RAM $00:2000–$00:7DFF.\nPIA $7FA0 · VIA $7FC0 · USB VIA $7FE0.\nSelect SXB + EDU for expansion examples and pin reference.";
    }
    private sealed record Sample(string Name, string File) { public override string ToString() => Name; }
    private sealed class Preferences { public Preferences() { } public string? File { get; set; } public string? Port { get; set; } public bool Edu { get; set; } = true; }
    private const string EduReference = "W65C816EDU • Board profile (selected manually)\n\n8 LEDs: PIA Port A ($7FA0), active high. Configure direction via CRA ($7FA1).\nBuzzer: PIA CA2. Enable the physical buzzer switch.\n\nI²C: VIA PA0=SCL, PA7=SDA ($7FC1 / DDRA $7FC3). Open-drain bit banging.\nSPI: PB0=SCK, PB1=MOSI, PB5=MISO, PB2=SRAM CS, PB3=mikroBUS CS.\n\n512 KB SRAM: $08:0000–$0F:FFFF per WDC's getting-started correction. Program upload stays in bank 0; use long addressing for EDU data.\n\nRTC: MCP79411 · ADC: ADS1015 · temperature: MCP9700A to ADC AIN2 · serial SRAM: 23LCV1024 · security: ATECC608A.\n\nExamples: LED chase, buzzer, banked RAM check, I²C scanner, SPI SRAM, OLED text, OLED 512K RAM tester, OLED RTC clock, large Fahrenheit temperature display, and OLED primes to 1 million. Basic RTC/OLED routines are included in standalone OLED samples. Some other peripheral drivers are not included.\n\nRead the bundled EDU guide for setup, results and official documentation links.";
    private const string SyntaxXml = """
    <SyntaxDefinition name="65816" xmlns="http://icsharpcode.net/sharpdevelop/syntaxdefinition/2008">
      <Color name="Comment" foreground="#000000" fontStyle="italic"/>
      <Color name="Opcode" foreground="#000000" fontWeight="bold"/>
      <Color name="Number" foreground="#000000"/>
      <Color name="Directive" foreground="#000000"/>
      <Color name="String" foreground="#000000"/>
      <RuleSet ignoreCase="true">
        <Span color="Comment" begin=";"/>
        <Span color="String" begin="&quot;" end="&quot;"/>
        <Rule color="Number">\$[0-9a-f]+|%[01]+|\b[0-9]+\b</Rule>
        <Rule color="Directive">\.[a-z_][a-z0-9_]*</Rule>
        <Keywords color="Opcode"><Word>lda</Word><Word>ldx</Word><Word>ldy</Word><Word>sta</Word><Word>stx</Word><Word>sty</Word><Word>stz</Word><Word>adc</Word><Word>sbc</Word><Word>and</Word><Word>ora</Word><Word>eor</Word><Word>bit</Word><Word>cmp</Word><Word>cpx</Word><Word>cpy</Word><Word>inc</Word><Word>dec</Word><Word>inx</Word><Word>dex</Word><Word>iny</Word><Word>dey</Word><Word>asl</Word><Word>lsr</Word><Word>rol</Word><Word>ror</Word><Word>jmp</Word><Word>jml</Word><Word>jsr</Word><Word>jsl</Word><Word>rts</Word><Word>rtl</Word><Word>rti</Word><Word>bra</Word><Word>brl</Word><Word>bne</Word><Word>beq</Word><Word>bpl</Word><Word>bmi</Word><Word>bcc</Word><Word>bcs</Word><Word>bvc</Word><Word>bvs</Word><Word>clc</Word><Word>sec</Word><Word>cld</Word><Word>sed</Word><Word>sei</Word><Word>cli</Word><Word>clv</Word><Word>rep</Word><Word>sep</Word><Word>xce</Word><Word>xba</Word><Word>tax</Word><Word>tay</Word><Word>txa</Word><Word>tya</Word><Word>tcd</Word><Word>tdc</Word><Word>tcs</Word><Word>tsc</Word><Word>tsx</Word><Word>txs</Word><Word>txy</Word><Word>tyx</Word><Word>pha</Word><Word>pla</Word><Word>phx</Word><Word>plx</Word><Word>phy</Word><Word>ply</Word><Word>php</Word><Word>plp</Word><Word>phb</Word><Word>plb</Word><Word>phd</Word><Word>pld</Word><Word>phk</Word><Word>pea</Word><Word>pei</Word><Word>per</Word><Word>mvn</Word><Word>mvp</Word><Word>nop</Word><Word>brk</Word><Word>cop</Word><Word>wai</Word><Word>stp</Word><Word>trb</Word><Word>tsb</Word></Keywords>
      </RuleSet>
    </SyntaxDefinition>
    """;
}
